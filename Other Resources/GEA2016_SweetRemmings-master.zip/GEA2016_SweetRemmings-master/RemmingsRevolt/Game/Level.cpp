#include "Level.h"
#include "GameData.h"
#include "DrawData2D.h"
#include "Input.h"
#include "WICTextureLoader.h"
#include "helper.h"
#include "ButtonManager.h"
#include <iostream>


Level::Level(GameData* _GD, ID3D11Device* _D, string _fileName, string _circleFileName, string _brickFileName, string _name, string _entranceFileName, string _exitFileName, Vector2 _spawnPoint, Vector2 _exitPoint, int _lemmingCount, int _targetSaved, BehaviourCount* _behaveCounts)
	: ImageGO2D(_GD, _fileName, _D), m_levelName(_name), m_totalLemmingCount(_lemmingCount), m_collider(nullptr), m_spawnTimer(0), m_targetSaved(_targetSaved), m_spawnPoint(_spawnPoint), m_spawnRate(50), m_savedCount(0), m_lemmingCount(0)
{
	m_renderTarget = new RenderTarget(_D, m_size.x, m_size.y);
	m_collider = new ColliderMask(&m_pos, this, m_GD->m_collisionGroup, m_renderTarget, true);

	m_origin = Vector2::Zero;
	m_tag = "Level";
	m_behaveCounts = _behaveCounts;

	//create button manager
	m_buttonManager = new ButtonManager(m_GD, _behaveCounts);

	string fullfilename =
#if DEBUG
		"../Debug/"
#else
		"../Release/"
#endif
		+ _circleFileName + ".png";
	HRESULT hr = CreateWICTextureFromFile(_D, Helper::charToWChar(fullfilename.c_str()), nullptr, &m_circleTex);

	//this nasty thing is required to find out the size of this image!
	ID3D11Resource *pResource;
	D3D11_TEXTURE2D_DESC Desc;
	m_circleTex->GetResource(&pResource);
	((ID3D11Texture2D *)pResource)->GetDesc(&Desc);

	m_circleSize.x = Desc.Width;
	m_circleSize.y = Desc.Height;


	fullfilename =
#if DEBUG
		"../Debug/"
#else
		"../Release/"
#endif
		+ _brickFileName + ".png";
	hr = CreateWICTextureFromFile(_D, Helper::charToWChar(fullfilename.c_str()), nullptr, &m_brickTex);

	//this nasty thing is required to find out the size of this image!
	m_brickTex->GetResource(&pResource);
	((ID3D11Texture2D *)pResource)->GetDesc(&Desc);

	m_brickSize.x = Desc.Width;
	m_brickSize.y = Desc.Height;

	
	m_entrance = _GD->m_factory->CreateGameObject<StaticObject>(_GD, _D, _entranceFileName, _spawnPoint);
	m_exit = _GD->m_factory->CreateGameObject<Exit>(_GD, _D, this, _exitFileName, _exitPoint);


	m_GD->m_eventHandler->StartListen(this, &Level::OnObjectDeleted);
	m_GD->m_eventHandler->StartListen(this, &Level::OnLemmingExit);
}

Level::~Level()
{
	m_renderTarget->Unmap(m_GD->m_ImmediateContext);
	delete m_renderTarget;
	delete m_collider;

	m_GD->m_factory->Delete(m_entrance);
	m_GD->m_factory->Delete(m_exit);

	for (auto it = m_traps.begin(); it != m_traps.end(); ++it)
	{
		m_GD->m_factory->Delete(*it);
	}

	m_GD->m_eventHandler->StopListen(this, &Level::OnObjectDeleted);
	m_GD->m_eventHandler->StopListen(this, &Level::OnLemmingExit);
}

void Level::Tick()
{
	if (m_lemmingCount < m_totalLemmingCount)
	{
		SpawnLemmings();
	}
}

void Level::SpawnLemmings()
{
	float spawnTime = 50.0f / (float)m_spawnRate;
	if (m_spawnTimer > spawnTime)
	{
		Lemming* lemming = m_GD->m_factory->CreateGameObject<Lemming>(m_GD, "Data/Objects/Lemming_Walking_1", m_GD->m_Device);
		lemming->SetPos(m_spawnPoint);
		m_lemmings.push_back(lemming);

		m_spawnTimer -= spawnTime;
		m_lemmingCount++;
	}

	m_spawnTimer += m_GD->m_dt;
}


void Level::Draw(DrawData2D* _DD)
{
	//_DD->m_Sprites->End();

	//m_renderTarget->Begin(m_GD->m_ImmediateContext, false);
	//ImageGO2D::Draw(_DD);
	//m_renderTarget->End(m_GD->m_ImmediateContext);


	_DD->m_Sprites->Draw(m_renderTarget->GetShaderResourceView(), m_pos, nullptr, m_colour, m_rotation, m_origin, m_scale, SpriteEffects_None);


	//_DD->m_Sprites->Begin();
}

void Level::DrawTerrainElements(DrawData2D* _DD)
{
	if (m_holes.size() > 0 || m_bricks.size() > 0)
	{
		//Unmap
		m_renderTarget->Unmap(m_GD->m_ImmediateContext);

		//Begin render target
		m_renderTarget->Begin(m_GD->m_ImmediateContext, true);

		if (m_holes.size() > 0)
		{
			//begin sprites WITH IMMEDIATE AND THE SECOND POINTER THINGY
			_DD->m_Sprites->Begin(DirectX::SpriteSortMode::SpriteSortMode_Immediate, m_renderTarget->GetDigBlend());

			for (auto it = m_holes.begin(); it != m_holes.end(); ++it)
			{
				//draw
				_DD->m_Sprites->Draw(m_circleTex, it->first, nullptr, Color(1, 1, 1, 1), 0, m_circleSize * 0.5f, Vector2(1, 1) * it->second / m_circleSize.x, SpriteEffects_None);
			}
			m_holes.clear();

			//end sprites
			_DD->m_Sprites->End();
		}


		if (m_bricks.size() > 0)
		{
			//begin sprites WITH IMMEDIATE AND THE SECOND POINTER THINGY
			_DD->m_Sprites->Begin(DirectX::SpriteSortMode::SpriteSortMode_Immediate);

			for (auto it = m_bricks.begin(); it != m_bricks.end(); ++it)
			{
				//draw
				_DD->m_Sprites->Draw(m_brickTex, *it, nullptr, Color(1, 1, 1, 1), 0, m_brickSize * 0.5f, 1.0f, SpriteEffects_None);
			}
			m_bricks.clear();

			//end sprites
			_DD->m_Sprites->End();
		}

		//end render target
		m_renderTarget->End(m_GD->m_ImmediateContext);

		//remap
		m_renderTarget->Map(m_GD->m_ImmediateContext);
	}
}



void Level::DrawRenderTarget(DrawData2D* _DD)
{
	m_renderTarget->Begin(m_GD->m_ImmediateContext, false);

	_DD->m_Sprites->Begin();

	_DD->m_Sprites->Draw(m_pTextureRV, m_pos, nullptr, m_colour, m_rotation, m_origin, m_scale, SpriteEffects_None);

	_DD->m_Sprites->End();

	m_renderTarget->End(m_GD->m_ImmediateContext);

	m_renderTarget->Map(m_GD->m_ImmediateContext);
}

void Level::MakeHole(const Vector2& pos, const float& radius)
{
	m_holes.push_back(pair<Vector2, float>(pos, radius));
}
void Level::MakeBrick(const Vector2& pos)
{
	m_bricks.push_back(pos);
}

void Level::AddTrap(const string& fileName, const Vector2& pos)
{
	m_traps.push_back(m_GD->m_factory->CreateGameObject<Trap>(m_GD, m_GD->m_Device, fileName, pos));
}



void Level::SpawnRateInc()
{
	m_spawnRate = min(m_spawnRate + 1, 99);
}
void Level::SpawnRateDec()
{
	m_spawnRate = max(m_spawnRate - 1, 1);
}


void Level::killAllLemmings()
{
	for (auto it = m_lemmings.begin(); it != m_lemmings.end(); ++it)
	{
		m_GD->m_selectedBehType = BehaviourType::BehaviourBomberT;
		(*it)->changeBehaviour();
	}
}

void Level::OnObjectDeleted(const DeleteEvent& evnt)
{
	m_lemmings.erase(std::remove(m_lemmings.begin(), m_lemmings.end(), evnt.m_obj), m_lemmings.end());
}

void Level::OnLemmingExit(const ExitEvent& evnt)
{
	if (++m_savedCount >= m_targetSaved)
	{
		//Next level
		std::cout << "Level completed! Yay!" << std::endl;
	}
}