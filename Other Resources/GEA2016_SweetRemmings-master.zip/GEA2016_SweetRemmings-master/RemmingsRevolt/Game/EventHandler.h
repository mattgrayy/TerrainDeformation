#pragma once

#include <map>
#include <vector>
#include <unordered_set>
#include <queue>
#include <mutex>
#include <cassert>

//Function pointer to a member function that listens to events of type EventType
template<class T, typename EventType>
using ListenMemberFunction = void(T::*)(const EventType&);

//Function pointer to a static function that listens to events of type EventType
template<typename EventType>
using ListenStaticFunction = void(*)(const EventType&);


//Index for the map which holds the lambda functions which in turn call the listening member functions
//We use a pair of a memory address of the object and a string. The memory adress allows us to have member functions
//per object, and the string lets us have multiple member functions per object class
using LambdaFunctionIndex = std::pair<const void*, std::string>;


class EventHandler
{
public:
	EventHandler() = default;
	~EventHandler() = default;


	/// <summary>Starts listening to a given event type (non-static)</summary>
	/// <param name="obj">The object to call the member function on</param>
	/// <param name="memberFunction">The member function (non-static) to call when the event happens</param>
	/// <param name="keyName">If registering an object to multiple functions of the same event type, use this to differentiate them</param>
	template<typename T, typename EventType>
	void StartListen(T* obj, ListenMemberFunction<T, EventType> memberFunction, const std::string keyName = "Default")
	{
		//Get the event group for this event type, and add the member function
		EventGroup<EventType>::Add(obj, memberFunction, this, keyName);

		//Add ProcessEvents function to list
		processEventsFuncs.push_back(&EventGroup<EventType>::ProcessEvents);
	}

	/// <summary>Starts listening to a given event type (static)</summary>
	/// <param name="staticFunction">The function (static) to call when the event happens</param>
	template<typename EventType>
	void StartListen(ListenStaticFunction<EventType> staticFunction)
	{
		//Get the event group for this event type, and add the static function
		EventGroup<EventType>::Add(staticFunction, this);

		//Add ProcessEvents function to list
		processEventsFuncs.push_back(&EventGroup<EventType>::ProcessEvents);
	}

	/// <summary>Stops listening to a given event type (non-static)</summary>
	/// <param name="obj">The object to unregister the member function on</param>
	/// <param name="memberFunction">The member function (non-static) used when it started listening</param>
	/// <param name="keyName">If the object was listening to multiple functions of the same event type, use this to differentiate them</param>
	template<typename T, typename EventType>
	void StopListen(const T* obj, ListenMemberFunction<T, EventType> memberFunction, const std::string keyName = "Default")
	{
		//Get the event group for this event type, and remove the member function
		EventGroup<EventType>::Remove(obj, this, keyName);
	}

	/// <summary>Stops listening to a given event type (static)</summary>
	/// <param name="staticFunction">The function (static) used when started listening</param>
	template<typename EventType>
	void StopListen(ListenStaticFunction<EventType> staticFunction)
	{
		//Get the event group for this event type, and remove the static function
		EventGroup<EventType>::Remove(staticFunction, this);
	}

	/// <summary>Broadcasts an event to all listeners immediately.
	///          If you are on another thread, use Enqueue</summary>
	/// <param name="evnt">The object to be passed to the listeners.</param>
	template<typename EventType>
	void Broadcast(const EventType& evnt) const
	{
		//Get the event group for this event type, and call the broadcast
		EventGroup<EventType>::Broadcast(evnt, this);
	}

	/// <summary>Enqueues an event to be broadcast on the next Update call.
	///          This will delete evnt after it is broadcast.</summary>
	/// <param name="evnt">Pointer to a new object to be passed to the listeners.
	///                    It will be deleted automatically.</param>
	template<typename EventType>
	void Enqueue(EventType* evnt) const
	{
		//Get the event group for this event type, and call the broadcast
		EventGroup<EventType>::Enqueue(evnt, this);
	}

	/// <summary>Processes all of the events queued using Enqueue. Call this on the main thread.</summary>
	void ProcessEvents();


private:

	//List of all the ProcessEvents functions within the EventGroup<EventType> class
	std::vector<void(*)(const EventHandler*)> processEventsFuncs;


	//A seperate class is compiled for each type of event,
	//so essentially we can index listeners by the type of callback.
	//Unfortunately this means everything has to be static, but since
	//we store data by the eventHandler, they can remain entirely independant.
	template<typename EventType>
	class EventGroup
	{
	public:
		template<typename T>
		static void Add(T* obj, ListenMemberFunction<T, EventType> memberFunction, const EventHandler* eventHandler, const std::string keyName = "Default")
		{
			//Create a lambda which calls the member function on the object
			auto lambda = [obj, memberFunction](const EventType& evnt)
			{
				(obj->*memberFunction)(evnt);
			};

			//Store the lambda in the list, indexed by the object pointer and the key name, so we can later find and delete it
			data[eventHandler].listeners[MakeLambdaIndex(obj, keyName)] = lambda;
		}

		static void Add(ListenStaticFunction<EventType> staticFunction, const EventHandler* eventHandler)
		{
			//Add the static function to the static listeners list
			data[eventHandler].staticListeners.insert(staticFunction);
		}

		template<typename T>
		static void Remove(const T* obj, const EventHandler* eventHandler, const std::string keyName = "Default")
		{
			auto index = MakeLambdaIndex(obj, keyName);

			//Make sure we have a matching listener, if not throw an error
			assert(data.count(eventHandler) > 0);
			assert(data[eventHandler].listeners.count(index) > 0);

			//Remove the lambda indexed by the object pointer and the key name
			data[eventHandler].listeners.erase(index);
		}

		static void Remove(ListenStaticFunction<EventType> staticFunction, const EventHandler* eventHandler)
		{
			//Make sure we have a matching listener, if not throw an error
			assert(data.count(eventHandler) > 0);
			assert(data[eventHandler].staticListeners.count(staticFunction) > 0);

			//Remove the function from the list
			data[eventHandler].staticListeners.erase(staticFunction);
		}

		static void Broadcast(const EventType& evnt, const EventHandler* eventHandler)
		{
			if (data.count(eventHandler) > 0)
			{
				auto& staticListeners = data[eventHandler].staticListeners;
				//Call each static function, passing it the event
				for (auto staticFunc : staticListeners)
				{
					staticFunc(evnt);
				}

				auto& maps = data[eventHandler].listeners;
				//Call each lambda in the non-static listener list,
				//which in turn calls the member function
				for (auto map : maps)
				{
					map.second(evnt);
				}
			}
		}

		static void Enqueue(EventType* evnt, const EventHandler* eventHandler)
		{
			EventHandlerData& dat = data[eventHandler];
			std::lock_guard<std::mutex> guard(dat.eventsToProcess_Mutex);
			dat.eventsToProcess.push(evnt);
		}

		static void ProcessEvents(const EventHandler* eventHandler)
		{
			EventHandlerData& dat = data[eventHandler];
			std::lock_guard<std::mutex> guard(dat.eventsToProcess_Mutex);
			auto& queue = dat.eventsToProcess;
			while(queue.size() > 0)
			{
				Broadcast(*queue.front(), eventHandler);
				delete queue.front();
				queue.pop();
			}
		}

	private:
		EventGroup() = default;
		~EventGroup() = default;

		//Using a map with index as the event handler allows us to have
		//seperate listeners per event handler, and thus multiple event
		//handlers. This effectively lets us store templated data on the
		//event handler, without having the event handler templated itself

		//This struct houses all the templated data the event handler needs
		struct EventHandlerData
		{
		public:
			//A list of all the lambdas that call the member functions,
			//indexed by the object pointer and the key name
			std::map<LambdaFunctionIndex,
				std::function<void(const EventType&)>
			> listeners;

			//A vector of all the static listener functions

			std::unordered_set<ListenStaticFunction<EventType>> staticListeners;

			//The queue for the events to process, used for Enqueue
			std::queue<EventType*> eventsToProcess;
			std::mutex eventsToProcess_Mutex;
		};

		//This is the map which lets us store data on the event handlers
		static std::map<const EventHandler*, EventHandlerData> data;
	};


	//Helper function to create the lambda map indexer
	template<typename T>
	static LambdaFunctionIndex MakeLambdaIndex(T* obj, std::string keyName)
	{
		return LambdaFunctionIndex(static_cast<const void*>(obj), keyName);
	}
};

template<typename EventType>
std::map<const EventHandler*, typename EventHandler::EventGroup<EventType>::EventHandlerData> EventHandler::EventGroup<EventType>::data;
