#include "BehaviourDigger.h"
#include "GameData.h"
#include "BehaviourManager.h"
#include "Level.h"

BehaviourDigger::BehaviourDigger(GameData* _GD)
	: Behaviour(_GD)
{
}


BehaviourDigger::~BehaviourDigger()
{
}

void BehaviourDigger::OnHitFloor(Lemming* lemming)
{
	if (digging && m_fallTimer >= 0.5f)
	{
		lemming->resetBehaviour();
		m_fallTimer = 0.0f;
		return;
	}
	if (!digging)
	{
		digging = true;
	}
	m_GD->m_behaviorManager->_level->MakeHole(Vector2(lemming->GetPos().x, lemming->GetPos().y + (lemming->GetColBox()->GetSize().y/4)), lemming->GetColBox()->GetSize().y);
	lemming->GetPos().y -= m_GD->m_dt * lemming->GetVelocity().y;

	if (m_fallTimer > 3.0f)
	{
		lemming->kill();
	}
	m_fallTimer = 0.0f;
}