#include "Collider.h"
#include "Collision.h"
#include "ColliderPoint.h"


Collider::Collider(Vector2* position, GameObject2D* gameObj, Collision* collisionGroup, bool isStatic, bool isTrigger)
	: m_pos(position), m_gameObject(gameObj), m_collisionGroup(collisionGroup), m_isStatic(isStatic), m_isTrigger(isTrigger)
{
	m_collisionGroup->AddCollider(this);
}


Collider::~Collider()
{
	m_collisionGroup->RemoveCollider(this);
}


void Collider::AddCollideTag(const string& tag)
{
	m_collidesWith.insert(tag);
}
void Collider::RemoveCollideTag(const string& tag)
{
	m_collidesWith.erase(tag);
}
void Collider::CollideWithAll()
{
	m_collidesWith.clear();
}
bool Collider::Intersects(const ColliderPoint* const col, Vector2& moveOffset) const
{
	return Intersects(*col->m_pos + col->GetOffset(), moveOffset);
}