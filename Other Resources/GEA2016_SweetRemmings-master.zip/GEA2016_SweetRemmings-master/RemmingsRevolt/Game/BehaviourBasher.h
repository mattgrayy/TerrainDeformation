#pragma once
#include "Behaviour.h"
class BehaviourBasher :
	public Behaviour
{
public:
	BehaviourBasher(GameData* _GD);
	virtual ~BehaviourBasher();

	virtual void OnHitWall(Lemming* lemming);

	virtual void Tick(Lemming* lemming);

private:
	float m_bashTimer;
};