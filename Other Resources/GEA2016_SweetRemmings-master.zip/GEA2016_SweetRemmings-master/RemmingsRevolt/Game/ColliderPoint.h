#pragma once
#include "Collider.h"
class ColliderPoint : public Collider
{
public:
	ColliderPoint(Vector2* position, GameObject2D* gameObj, Collision* collisionGroup, const Vector2& offset, bool isStatic = false, bool isTrigger = false);
	virtual ~ColliderPoint();

	void SetOffset(const Vector2& offset);
	const Vector2& GetOffset() const;

	bool Intersects(const Vector2& point, Vector2& moveOffset) const override;
	bool Intersects(const Collider* const col, Vector2& moveOffset) const override;
	bool Intersects(const ColliderBox* const col, Vector2& moveOffset) const override;
	bool Intersects(const ColliderMask* const col, Vector2& moveOffset) const override;

private:
	Vector2 m_offset;
};

