#include "StaticObject.h"


StaticObject::StaticObject(GameData* _GD, ID3D11Device* _D, string _fileName, Vector2 _pos)
	: ImageGO2D(_GD, _fileName, _D)
{
	m_pos = _pos;
}


StaticObject::~StaticObject()
{
}
