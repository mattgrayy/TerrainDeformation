#include "ButtonBehaviour.h"
#include "GameData.h"
#include "DrawData2D.h"
#include "Input.h"
#include <iostream>

ButtonBehaviour::ButtonBehaviour(GameData* _GD, string _filename, ID3D11Device* _D, BehaviourType butHaviour, int butUses, int posIndex)
	: Button(_GD, _filename, _D, posIndex), m_behaviour(butHaviour), m_uses(butUses)
{
	SetText(butUses);
}

ButtonBehaviour::~ButtonBehaviour()
{}

void ButtonBehaviour::Tick()
{
	Button::Tick();

	SetText(m_uses);
}

void ButtonBehaviour::OnClicked()
{
	if (m_uses > 0)
	{
		m_GD->m_selectedBehType = m_behaviour;
		m_GD->m_selectedButton = this;
	}
}