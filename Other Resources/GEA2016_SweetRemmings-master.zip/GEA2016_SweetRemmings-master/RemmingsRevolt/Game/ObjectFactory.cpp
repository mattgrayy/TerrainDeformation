#include "ObjectFactory.h"
#include "rapidjson/filereadstream.h"
#include "rapidjson/document.h"

#include "Level.h"

ObjectFactory::~ObjectFactory()
{
	//clear scene object list and memory
	for (auto it = m_gameObjects.begin(); it != m_gameObjects.end(); ++it)
	{
		delete *it;
		*it = nullptr;
	}
	//clear the list
	m_gameObjects.clear();
}


void ObjectFactory::Delete(GameObject2D* obj)
{
	m_objsToDelete.push_back(obj);

	m_eventHandler->Broadcast(DeleteEvent(obj));
}

void ObjectFactory::DoDeletion()
{
	for (auto it = m_objsToDelete.begin(); it != m_objsToDelete.end(); ++it)
	{

		m_gameObjects.erase(std::remove(m_gameObjects.begin(), m_gameObjects.end(), *it), m_gameObjects.end());
		delete *it;
	}
	m_objsToDelete.clear();
}

const std::list<GameObject2D*>& ObjectFactory::GetGameObject2Ds() const
{
	return m_gameObjects;
}

Level* ObjectFactory::LoadLevelFromFile(GameData* _GD, ID3D11Device* _D, string fileName)
{
	string basePath = "Data/Levels/";
	fileName = 
#if DEBUG
		"../Debug/"
#else
		"../Release/"
#endif
	+ basePath + fileName + ".JSON";
	FILE* fp = fopen(fileName.c_str(), "rb");
	char readBuffer[65536];
	rapidjson::FileReadStream is(fp, readBuffer, sizeof(readBuffer));
	rapidjson::Document levelFile;
	levelFile.ParseStream(is);
	fclose(fp);

	assert(levelFile.IsObject()); //check if valid JSON file

	assert(levelFile.HasMember("Level")); //check for level

	///check for level data
	//level image
	assert(levelFile["Level"].HasMember("ImageURL"));
	assert(levelFile["Level"]["ImageURL"].IsString());
	string imageURL = levelFile["Level"]["ImageURL"].GetString();

	//level name
	assert(levelFile["Level"].HasMember("Name"));
	assert(levelFile["Level"]["Name"].IsString());
	string name = levelFile["Level"]["Name"].GetString();

	//lemming count
	assert(levelFile["Level"].HasMember("Lemmings"));
	assert(levelFile["Level"]["Lemmings"].IsInt());
	int lemmingCount = levelFile["Level"]["Lemmings"].GetInt();

	//lemming save target
	assert(levelFile["Level"].HasMember("SaveTarget"));
	assert(levelFile["Level"]["SaveTarget"].IsInt());
	int saveCount = levelFile["Level"]["SaveTarget"].GetInt();

	//lemming spawn x
	assert(levelFile["Level"].HasMember("SpawnX"));
	assert(levelFile["Level"]["SpawnX"].IsInt());
	int posX = levelFile["Level"]["SpawnX"].GetInt();

	//lemming spawn y
	assert(levelFile["Level"].HasMember("SpawnY"));
	assert(levelFile["Level"]["SpawnY"].IsInt());
	int posY = levelFile["Level"]["SpawnY"].GetInt();

	///entrance
	assert(levelFile["Level"].HasMember("Entrance")); //check for behaviours

	//entrance image
	assert(levelFile["Level"]["Entrance"].HasMember("ImageURL"));
	assert(levelFile["Level"]["Entrance"]["ImageURL"].IsString());
	string entranceImgURL = levelFile["Level"]["Entrance"]["ImageURL"].GetString();

	///exit
	assert(levelFile["Level"].HasMember("Exit")); //check for behaviours

	//exit image
	assert(levelFile["Level"]["Exit"].HasMember("ImageURL"));
	assert(levelFile["Level"]["Exit"]["ImageURL"].IsString());
	string exitImgURL = levelFile["Level"]["Exit"]["ImageURL"].GetString();

	//exit x
	assert(levelFile["Level"]["Exit"].HasMember("ExitX"));
	assert(levelFile["Level"]["Exit"]["ExitX"].IsInt());
	int exitX = levelFile["Level"]["Exit"]["ExitX"].GetInt();

	//exit y
	assert(levelFile["Level"]["Exit"].HasMember("ExitY"));
	assert(levelFile["Level"]["Exit"]["ExitY"].IsInt());
	int exitY = levelFile["Level"]["Exit"]["ExitY"].GetInt();

	///behaviours
	assert(levelFile["Level"].HasMember("Behaviours")); //check for behaviours

	//Basher count
	assert(levelFile["Level"]["Behaviours"].HasMember("Basher"));
	assert(levelFile["Level"]["Behaviours"]["Basher"].IsInt());
	int basherCount = levelFile["Level"]["Behaviours"]["Basher"].GetInt();

	//Blocker count
	assert(levelFile["Level"]["Behaviours"].HasMember("Blocker"));
	assert(levelFile["Level"]["Behaviours"]["Blocker"].IsInt());
	int blockerCount = levelFile["Level"]["Behaviours"]["Blocker"].GetInt();

	//Bomber count
	assert(levelFile["Level"]["Behaviours"].HasMember("Bomber"));
	assert(levelFile["Level"]["Behaviours"]["Bomber"].IsInt());
	int bomberCount = levelFile["Level"]["Behaviours"]["Bomber"].GetInt();

	//Builder count
	assert(levelFile["Level"]["Behaviours"].HasMember("Builder"));
	assert(levelFile["Level"]["Behaviours"]["Builder"].IsInt());
	int builderCount = levelFile["Level"]["Behaviours"]["Builder"].GetInt();

	//Climber count
	assert(levelFile["Level"]["Behaviours"].HasMember("Climber"));
	assert(levelFile["Level"]["Behaviours"]["Climber"].IsInt());
	int climberCount = levelFile["Level"]["Behaviours"]["Climber"].GetInt();

	//Digger count
	assert(levelFile["Level"]["Behaviours"].HasMember("Digger"));
	assert(levelFile["Level"]["Behaviours"]["Digger"].IsInt());
	int diggerCount = levelFile["Level"]["Behaviours"]["Digger"].GetInt();

	//Floater count
	assert(levelFile["Level"]["Behaviours"].HasMember("Floater"));
	assert(levelFile["Level"]["Behaviours"]["Floater"].IsInt());
	int floaterCount = levelFile["Level"]["Behaviours"]["Floater"].GetInt();

	//Miner count
	assert(levelFile["Level"]["Behaviours"].HasMember("Miner"));
	assert(levelFile["Level"]["Behaviours"]["Miner"].IsInt());
	int minerCount = levelFile["Level"]["Behaviours"]["Miner"].GetInt();

	BehaviourCount behaveCounts = BehaviourCount(basherCount, blockerCount, bomberCount, builderCount, climberCount, diggerCount, floaterCount, minerCount);
	//create the level object
	Level* newLevel = new Level(_GD, _D, imageURL, "Data/Objects/Explosion", "Data/Objects/Brick", name, entranceImgURL, exitImgURL, Vector2(posX, posY), Vector2(exitX, exitY), lemmingCount, saveCount, &behaveCounts);
	m_gameObjects.push_back(newLevel);

	///traps
	//components
	if (levelFile["Level"].HasMember("Traps"))
	{
		assert(levelFile["Level"]["Traps"].IsArray());
		for (int i = 0; i < levelFile["Level"]["Traps"].Size(); i += 3)
		{
			newLevel->AddTrap(levelFile["Level"]["Traps"][i].GetString(), Vector2(levelFile["Level"]["Traps"][1 + i].GetInt(), levelFile["Level"]["Traps"][2 + i].GetInt()));
		}
	}

	return newLevel;
}
