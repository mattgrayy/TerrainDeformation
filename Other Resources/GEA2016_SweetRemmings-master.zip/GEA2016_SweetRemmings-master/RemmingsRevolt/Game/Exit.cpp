#include "Exit.h"
#include "Collision.h"
#include "Lemming.h"
#include "Level.h"
#include "EventHandler.h"
#include "GameData.h"

Exit::Exit(GameData* _GD, ID3D11Device* _D, Level* _level, string _fileName, Vector2 _pos)
	: TriggerObject(_GD, _D, _fileName, _pos)
{
	m_tag = "Exit";
	m_level = _level;
}


Exit::~Exit()
{
}

void Exit::OnTriggerHit(const TriggerEvent& evnt)
{
	if (evnt.obj1 != this)
	{
		return;
	}
	if (evnt.obj2->GetTag() == "Lemming")
	{
		Lemming* lemming = static_cast<Lemming*>(evnt.obj2);

		m_GD->m_eventHandler->Broadcast(ExitEvent(lemming));

		lemming->kill();
	}
}