#include "Collision.h"
#include <algorithm>
#include <string>
#include "GameObject2D.h"
#include "EventHandler.h"

#include <iostream>


Collision::Collision()
{
}

Collision::~Collision()
{
}

void Collision::Update(EventHandler* eventHandler)
{
	//Do collision check between all colliders

	for (auto it1 = m_colliders.begin(); it1 != m_colliders.end(); ++it1)
	{
		Collider* col1 = *it1;

		auto start2 = it1;
		++start2;
		for (auto it2 = start2; it2 != m_colliders.end(); ++it2)
		{
			Collider* col2 = *it2;

			if (CheckTagsCollidesWith(col1, col2))
			{
				Vector2 moveOffset;
				if (col1->Intersects(col2, moveOffset))
				{
					//If either are a trigger, then dont move either
					if (!col1->m_isTrigger && !col2->m_isTrigger)
					{
						//Neither are triggers
						if (!col1->m_isStatic)
						{
							if (!col2->m_isStatic)
							{
								//Neither are static, move both away from each other by half
								*col1->m_pos += moveOffset * 0.5f;
								*col2->m_pos -= moveOffset * 0.5f;
							}
							else
							{
								//col2 is static, move col1 away
								*col1->m_pos += moveOffset;
							}
						}
						else if (!col2->m_isStatic)
						{
							//col1 is static, move col2 away
							*col2->m_pos -= moveOffset;
						}
						//else both are static, dont move either
					}

					if (eventHandler != nullptr)
					{
						if (col1->m_isTrigger)
						{
							eventHandler->Enqueue(new TriggerEvent(col1->m_gameObject, col2->m_gameObject, col1, col2));
						}

						if (col2->m_isTrigger)
						{
							eventHandler->Enqueue(new TriggerEvent(col2->m_gameObject, col1->m_gameObject, col2, col1));
						}
						else if (!col1->m_isTrigger)
						{
							//Neither are triggers
							eventHandler->Enqueue(new CollisionEvent(col1->m_gameObject, col2->m_gameObject, col1, col2, moveOffset));
							eventHandler->Enqueue(new CollisionEvent(col2->m_gameObject, col1->m_gameObject, col2, col1, -moveOffset));
						}
					}
				}
			}
		}
	}
}


void Collision::AddCollider(Collider* col)
{
	m_colliders.insert(col);
}
void Collision::RemoveCollider(Collider* col)
{
	m_colliders.erase(col);
}

GameObject2D* Collision::PointCast(const Vector2& point) const
{
	for (auto it = m_colliders.begin(); it != m_colliders.end(); ++it)
	{
		Vector2 notInUse;
		if ((*it)->Intersects(point, notInUse))
		{
			return (*it)->m_gameObject;
		}
	}

	return nullptr;
}

bool Collision::CheckTagsCollidesWith(const Collider* const col1, const Collider* const col2) const
{
	bool collides1 = false;
	bool collides2 = false;

	if (col1->m_collidesWith.size() == 0)
	{
		//Empty list = collides with all
		collides1 = true;
	}
	if (col2->m_collidesWith.size() == 0)
	{
		//Empty list = collides with all
		collides2 = true;
	}


	//If they dont collide, see if they have matching tags
	if (!collides1)
	{
		auto find1 = col1->m_collidesWith.find(col2->m_gameObject->GetTag());
		if (find1 != col1->m_collidesWith.end())
		{
			collides1 = true;
		}
	}
	if (!collides2)
	{
		auto find2 = col2->m_collidesWith.find(col1->m_gameObject->GetTag());
		if (find2 != col2->m_collidesWith.end())
		{
			collides2 = true;
		}
	}

	//They only collide if they both agree
	return collides1 && collides2;
}



