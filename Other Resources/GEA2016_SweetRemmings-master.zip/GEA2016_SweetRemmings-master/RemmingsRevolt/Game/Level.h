#pragma once

#include "Lemming.h"
#include "ImageGO2D.h"
#include "ColliderMask.h"
#include "StaticObject.h"
#include "Trap.h"
#include "Exit.h"
#include "EventHandler.h"
#include "ObjectFactory.h"

struct BehaviourCount;
class ButtonManager;

class Level : public ImageGO2D
{
public:

	Level(GameData* _GD, ID3D11Device* _D, string _fileName, string _circleFileName, string _brickFileName, string _name, string _entranceFileName, string _exitFileName, Vector2 _spawnPoint, Vector2 _exitPoint, int _lemmingCount, int _targetSaved, BehaviourCount* _behaveCounts);
	~Level();

	virtual void Tick();

	virtual void Draw(DrawData2D* _DD);
	void DrawTerrainElements(DrawData2D* _DD);

	void DrawRenderTarget(DrawData2D* _DD);

	void MakeHole(const Vector2& pos, const float& radius);
	void MakeBrick(const Vector2& pos);

	void AddTrap(const string& fileName, const Vector2& pos);

	void SpawnRateInc();
	void SpawnRateDec();
	int GetSpawnRate() { return m_spawnRate; }

	void killAllLemmings();


	ButtonManager* m_buttonManager;

	BehaviourCount* getBehaveCounts(){ return m_behaveCounts; }

private:
	void SpawnLemmings();

	void OnObjectDeleted(const DeleteEvent& evnt);
	void OnLemmingExit(const ExitEvent& evnt);

	ID3D11ShaderResourceView* m_circleTex;
	ID3D11ShaderResourceView* m_brickTex;
	Vector2 m_circleSize; //Used to set the origin
	Vector2 m_brickSize;

	string m_levelName;
	int m_lemmingCount, m_totalLemmingCount,
		m_savedCount,   m_targetSaved;

	float m_spawnTimer;
	int m_spawnRate;
	std::list<Lemming*> m_lemmings;
	ColliderMask* m_collider;
	RenderTarget* m_renderTarget;

	vector<pair<const Vector2, const float>> m_holes;
	vector<const Vector2> m_bricks;

	StaticObject* m_entrance;
	Vector2 m_spawnPoint;

	Exit* m_exit;
	vector<Trap*> m_traps;

	BehaviourCount* m_behaveCounts;
};

