#include "TextGO2D.h"
#include "DrawData2D.h"
#include "helper.h"
#include "GameData.h"

TextGO2D::TextGO2D(GameData* _GD, string* _text)
	: GameObject2D(_GD)
{
	m_text = _text;
}



void TextGO2D::Tick()
{
	GameObject2D::Tick();
}


void TextGO2D::Draw(DrawData2D* _DD)
{
	_DD->m_Font->DrawString(_DD->m_Sprites.get(), Helper::charToWChar(m_text->c_str()), m_pos, Colors::Black, m_rotation, m_origin, Vector2(0.5f,0.5f));
}