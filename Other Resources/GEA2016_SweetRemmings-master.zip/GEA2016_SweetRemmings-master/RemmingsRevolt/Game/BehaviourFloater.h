#pragma once
#include "Behaviour.h"
class BehaviourFloater :
	public Behaviour
{
public:
	BehaviourFloater(GameData* _GD);
	virtual ~BehaviourFloater();
	virtual void OnHitFloor(Lemming* lemming);

	virtual void Init(Lemming* lemming);

	virtual void Tick(Lemming* lemming);
};

