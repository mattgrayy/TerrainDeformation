#pragma once
#include "Behaviour.h"
class BehaviourMiner :
	public Behaviour
{
public:
	BehaviourMiner(GameData* _GD);
	virtual ~BehaviourMiner();

	virtual void OnHitFloor(Lemming* lemming);
private:
	bool digging = false;
};

