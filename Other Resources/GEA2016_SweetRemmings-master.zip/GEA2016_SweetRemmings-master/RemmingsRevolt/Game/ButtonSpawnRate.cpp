#include "ButtonSpawnRate.h"
#include "BehaviourManager.h"
#include "Level.h"


ButtonSpawnRate::ButtonSpawnRate(GameData* _GD, string _filename, ID3D11Device* _D, int posIndex, bool isAdder)
	: Button(_GD, _filename, _D, posIndex), m_isAdder(isAdder)
{
}


ButtonSpawnRate::~ButtonSpawnRate()
{
}


void ButtonSpawnRate::Tick()
{
	Button::Tick();

	SetText(m_GD->m_behaviorManager->_level->GetSpawnRate());
}

void ButtonSpawnRate::OnClicked()
{
	if (m_isAdder)
	{
		m_GD->m_behaviorManager->_level->SpawnRateInc();
	}
	else
	{
		m_GD->m_behaviorManager->_level->SpawnRateDec();
	}
}