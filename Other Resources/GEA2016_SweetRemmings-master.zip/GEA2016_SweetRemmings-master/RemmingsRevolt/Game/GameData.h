#ifndef _GAME_DATA_H_
#define _GAME_DATA_H_

//=================================================================
//Data to be passed by game to all Game Objects via Tick
//=================================================================
#include "GameState.h"
#include "EventHandler.h"
#include "Collision.h"
#include "ObjectFactory.h"
#include "Debug.h"

class ButtonBehaviour;
class Behaviour;
class BehaviourManager;

using namespace DirectX;

enum class BehaviourType
{
	BehaviourNone,
	BehaviourBaseT,
	BehaviourBasherT,
	BehaviourBlockerT,
	BehaviourBomberT,
	BehaviourBuilderT,
	BehaviourClimberT,
	BehaviourDiggerT,
	BehaviourFloaterT,
	BehaviourMinerT
};

struct GameData
{
	float m_dt;  //time step since last frame
	GameState m_GS; //global GameState

	ID3D11Device* m_Device; //graphics device
	ID3D11DeviceContext* m_ImmediateContext;

	//system components
	ObjectFactory* m_factory;
	EventHandler* m_eventHandler;
	Collision* m_collisionGroup;
	Debug* m_debug;

	//Behaviour stuff
	BehaviourManager* m_behaviorManager;
	BehaviourType m_selectedBehType;

	ButtonBehaviour* m_selectedButton;
};
#endif
