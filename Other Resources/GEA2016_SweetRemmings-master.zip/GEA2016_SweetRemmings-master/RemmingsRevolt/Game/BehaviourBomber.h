#pragma once
#include "Behaviour.h"

class BehaviourBomber :
	public Behaviour
{
public:
	BehaviourBomber(GameData* _GD);
	virtual ~BehaviourBomber();

	virtual void Tick(Lemming* lemming);

private:
	float m_bombTimer;
};

