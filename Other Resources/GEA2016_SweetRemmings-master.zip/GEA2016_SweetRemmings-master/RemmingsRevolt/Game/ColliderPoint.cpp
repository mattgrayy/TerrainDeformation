#include "ColliderPoint.h"
#include "ColliderBox.h"
#include "ColliderMask.h"


ColliderPoint::ColliderPoint(Vector2* position, GameObject2D* gameObj, Collision* collisionGroup, const Vector2& offset, bool isStatic, bool isTrigger)
	: Collider(position, gameObj, collisionGroup, isStatic, isTrigger), m_offset(offset)
{
}


ColliderPoint::~ColliderPoint()
{
}

void ColliderPoint::SetOffset(const Vector2& offset)
{
	m_offset = offset;
}

const Vector2& ColliderPoint::GetOffset() const
{
	return m_offset;
}


bool ColliderPoint::Intersects(const Collider* const col, Vector2& moveOffset) const
{
	bool res = col->Intersects(this, moveOffset);
	moveOffset = -moveOffset;
	return res;
}
bool ColliderPoint::Intersects(const Vector2& point, Vector2& moveOffset) const
{
	if ((*m_pos + m_offset) == point)
	{
		if (!m_isTrigger) //If we are a trigger, dont bother with moveOffset
			moveOffset = Vector2::UnitY;
		return true;
	}
	return false;
}
bool ColliderPoint::Intersects(const ColliderBox* const col, Vector2& moveOffset) const
{
	return col->Collider::Intersects(this, moveOffset);
}
bool ColliderPoint::Intersects(const ColliderMask* const col, Vector2& moveOffset) const
{
	return col->Collider::Intersects(this, moveOffset);
}

