#pragma once

#include "Button.h"
#include "ImageGO2D.h"
#include "ObjectFactory.h"

class ButtonManager
{
public:
	ButtonManager(GameData* _GD, BehaviourCount* _behaveCounts);
	~ButtonManager();

	list<Button*> GetButtons()
	{
		return m_buttons;
	}

private:
	list<Button*> m_buttons;
};