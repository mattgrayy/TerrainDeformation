#include "BehaviourClimber.h"


BehaviourClimber::BehaviourClimber(GameData* _GD)
	: Behaviour(_GD)
{
}


BehaviourClimber::~BehaviourClimber()
{
}

void BehaviourClimber::OnHitWall(Lemming* lemming)
{
	lemming->GetPos().y -= m_GD->m_dt * lemming->GetVelocity().y;
	lemming->GetPos().x += m_GD->m_dt * lemming->GetVelocity().x;
	m_fallTimer = 0.0f;
	if (!m_climbing)
	{
		m_climbing = true;
	}
}

void BehaviourClimber::Tick(Lemming* lemming)
{
	OnFalling(lemming);

	if (!m_climbing)
	{
		lemming->GetPos().y += m_GD->m_dt * lemming->GetVelocity().y;
	}
	m_climbing = false;

	if (lemming->GetGrounded())
	{
		lemming->GetPos().x += m_GD->m_dt * lemming->GetVelocity().x;
	}
	lemming->SetGrounded(false);
}