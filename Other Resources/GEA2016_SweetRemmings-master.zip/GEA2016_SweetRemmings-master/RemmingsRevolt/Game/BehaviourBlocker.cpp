#include "BehaviourBlocker.h"


BehaviourBlocker::BehaviourBlocker(GameData* _GD)
	: Behaviour(_GD)
{
}


BehaviourBlocker::~BehaviourBlocker()
{
}

void BehaviourBlocker::Init(Lemming* lemming)
{
	// make lemming box collider NOT trigger
	lemming->GetColBox()->SetIsTrigger(false);
	lemming->SetTag("LemmingBlocker");
}

void BehaviourBlocker::Tick(Lemming* lemming)
{
	lemming->GetPos().y += m_GD->m_dt * lemming->GetVelocity().y;
}