#pragma once

#include <map>
#include <dinput.h>
#include <string>

using namespace std;

class Input
{
public:
	Input() = delete;
	~Input() = delete;
	Input(const Input&) = delete;
	Input operator=(const Input&) = delete;

	static void Start(HINSTANCE, HWND*);
	static bool Update();
	static void End();

	static bool GetButton(const string&);
	static bool GetButtonUp(const string&);
	static bool GetButtonDown(const string&);

	static float GetAxis(const string& positive, const string& negative);

	static int GetMouseX();
	static int GetMouseY();

	static bool GetMouseButton(int);
	static bool GetMouseButtonUp(int);
	static bool GetMouseButtonDown(int);

private:
	//input stuff
	static HWND* m_hWnd;

	static IDirectInput8* m_pDirectInput;
	static IDirectInputDevice8* m_pKeyboard;
	static IDirectInputDevice8* m_pMouse;

	static unsigned char m_keyboardState[256];
	static unsigned char m_prevKeyboardState[256];

	static DIMOUSESTATE m_mouseState;
	static bool m_prevMouse[4];

	static int m_mousePosX;
	static int m_mousePosY;

	static bool ReadKeyboard();
	static bool ReadMouse();


	static map<string, int> createInputStringMap()
	{
		map<string, int> m;
		m["Escape"] = DIK_ESCAPE;
		m["1"] = DIK_1;
		m["2"] = DIK_2;
		m["3"] = DIK_3;
		m["4"] = DIK_4;
		m["5"] = DIK_5;
		m["6"] = DIK_6;
		m["7"] = DIK_7;
		m["8"] = DIK_8;
		m["9"] = DIK_9;
		m["0"] = DIK_0;
		m["Minus"] = DIK_MINUS;
		m["Equals"] = DIK_EQUALS;
		m["Back"] = DIK_BACK;
		m["Tab"] = DIK_TAB;
		m["Q"] = DIK_Q;
		m["W"] = DIK_W;
		m["E"] = DIK_E;
		m["R"] = DIK_R;
		m["T"] = DIK_T;
		m["Y"] = DIK_Y;
		m["U"] = DIK_U;
		m["I"] = DIK_I;
		m["O"] = DIK_O;
		m["P"] = DIK_P;
		m["LBracket"] = DIK_LBRACKET;
		m["RBracket"] = DIK_RBRACKET;
		m["Return"] = DIK_RETURN;
		m["LControl"] = DIK_LCONTROL;
		m["A"] = DIK_A;
		m["S"] = DIK_S;
		m["D"] = DIK_D;
		m["F"] = DIK_F;
		m["G"] = DIK_G;
		m["H"] = DIK_H;
		m["J"] = DIK_J;
		m["K"] = DIK_K;
		m["L"] = DIK_L;
		m["Semicolon"] = DIK_SEMICOLON;
		m["Apostrophe"] = DIK_APOSTROPHE;
		m["Grave"] = DIK_GRAVE;
		m["LShift"] = DIK_LSHIFT;
		m["Backslash"] = DIK_BACKSLASH;
		m["Z"] = DIK_Z;
		m["X"] = DIK_X;
		m["C"] = DIK_C;
		m["V"] = DIK_V;
		m["B"] = DIK_B;
		m["N"] = DIK_N;
		m["M"] = DIK_M;
		m["Comma"] = DIK_COMMA;
		m["Period"] = DIK_PERIOD;
		m["Slash"] = DIK_SLASH;
		m["RShift"] = DIK_RSHIFT;
		m["Multiply"] = DIK_MULTIPLY;
		m["LMenu"] = DIK_LMENU;
		m["RMenu"] = DIK_RMENU;
		m["Space"] = DIK_SPACE;
		m["Capital"] = DIK_CAPITAL;
		m["F1"] = DIK_F1;
		m["F2"] = DIK_F2;
		m["F3"] = DIK_F3;
		m["F4"] = DIK_F4;
		m["F5"] = DIK_F5;
		m["F6"] = DIK_F6;
		m["F7"] = DIK_F7;
		m["F8"] = DIK_F8;
		m["F9"] = DIK_F9;
		m["F10"] = DIK_F10;
		m["Numpad7"] = DIK_NUMPAD7;
		m["Numpad8"] = DIK_NUMPAD8;
		m["Numpad9"] = DIK_NUMPAD9;
		m["Subtract"] = DIK_SUBTRACT;
		m["Numpad4"] = DIK_NUMPAD4;
		m["Numpad5"] = DIK_NUMPAD5;
		m["Numpad6"] = DIK_NUMPAD6;
		m["Add"] = DIK_ADD;
		m["Numpad1"] = DIK_NUMPAD1;
		m["Numpad2"] = DIK_NUMPAD2;
		m["Numpad3"] = DIK_NUMPAD3;
		m["Numpad0"] = DIK_NUMPAD0;
		m["Decimal"] = DIK_DECIMAL;
		m["F11"] = DIK_F11;
		m["F12"] = DIK_F12;
		m["F13"] = DIK_F13;
		m["F14"] = DIK_F14;
		m["F15"] = DIK_F15;
		m["NumpadEquals"] = DIK_NUMPADEQUALS;
		m["At"] = DIK_AT;
		m["Colon"] = DIK_COLON;
		m["Underline"] = DIK_UNDERLINE;
		m["NumpadEnter"] = DIK_NUMPADENTER;
		m["RControl"] = DIK_RCONTROL;
		m["NumpadComma"] = DIK_NUMPADCOMMA;
		m["Divide"] = DIK_DIVIDE;
		m["Up"] = DIK_UP;
		m["Left"] = DIK_LEFT;
		m["Right"] = DIK_RIGHT;
		m["End"] = DIK_END;
		m["Down"] = DIK_DOWN;
		m["Insert"] = DIK_INSERT;
		m["Delete"] = DIK_DELETE;

		m["Backspace"] = DIK_BACK;
		m["NumpadStar"] = DIK_MULTIPLY;
		m["LAlt"] = DIK_LMENU;
		m["CapsLock"] = DIK_CAPITAL;
		m["NumpadMinus"] = DIK_SUBTRACT;
		m["NumpadPlus"] = DIK_ADD;
		m["NumpadPeriod"] = DIK_DECIMAL;
		m["NumpadSlash"] = DIK_DIVIDE;
		m["RAlt"] = DIK_RMENU;
		m["UpArrow"] = DIK_UP;
		m["PgUp"] = DIK_PRIOR;
		m["LeftArrow"] = DIK_LEFT;
		m["RightArrow"] = DIK_RIGHT;
		m["DownArrow"] = DIK_DOWN;
		m["PgDn"] = DIK_NEXT;
		return m;
	}

	static const map<string, int> inputStrings;
};

