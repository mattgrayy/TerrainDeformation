#pragma once

#include "ImageGO2D.h"
#include "TextGO2D.h"
#include "ColliderBox.h"
#include "Behaviour.h"
#include "GameData.h"

//Create Args: GameData* _GD, string _filename, ID3D11Device* _D, Behaviour* butHaviour, int butUses, int posIndex
//The in-game UI button class.
class Button : public ImageGO2D
{
public:
	Button(GameData* _GD, string _filename, ID3D11Device* _D, int posIndex);
	virtual ~Button();

	virtual void Tick();

	virtual void OnClicked();

	void SetText(int i);

private:
	TextGO2D* m_textObj; //text object
	string m_textDpl; //text display
	ColliderBox* m_butCollider;
};