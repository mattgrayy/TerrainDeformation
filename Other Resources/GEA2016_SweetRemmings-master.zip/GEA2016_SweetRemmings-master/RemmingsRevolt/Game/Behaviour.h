#pragma once
#include "GameData.h"
#include "Lemming.h"

class Behaviour
{
public:
	Behaviour(GameData* _GD);
	virtual ~Behaviour();

	virtual void OnHitWall(Lemming* lemming);
	virtual void OnHitFloor(Lemming* lemming);
	virtual void OnFalling(Lemming* lemming);

	virtual void Init(Lemming* lemming);

	virtual void Tick(Lemming* lemming);

	float getFallTimer(){ return m_fallTimer; }
	void setFallTimer(float _timer){ m_fallTimer = _timer; }

protected:

	GameData* m_GD;

	float m_fallTimer;
};