#include "game.h"
#include "GameData.h"
#include "drawdata.h"
#include "DrawData2D.h"
#include "Debug.h"
#include "GameObject2D.h"
#include "ObjectList.h"
#include "helper.h"
#include <windows.h>
#include <time.h>
#include "DDSTextureLoader.h"
#include <d3d11shader.h>
#include "Input.h"
#include "Level.h"
#include <thread>
#include <chrono>

using namespace DirectX;

Game::Game(ID3D11Device* _pd3dDevice, HWND _hWnd, HINSTANCE _hInstance) :m_playTime(0), m_fxFactory(nullptr), m_states(nullptr)
{
	//Create DirectXTK spritebatch stuff
	ID3D11DeviceContext* pd3dImmediateContext;
	_pd3dDevice->GetImmediateContext(&pd3dImmediateContext);
	m_DD2D = new DrawData2D();
	m_DD2D->m_Sprites.reset(new SpriteBatch(pd3dImmediateContext));
	m_DD2D->m_Font.reset(new SpriteFont(_pd3dDevice, L"italic.spritefont"));

	//seed the random number generator
	srand((UINT)time(NULL));

	//Direct Input Stuff
	m_hWnd = _hWnd;

	//Set up input stuff
	Input::Start(_hInstance, &m_hWnd);

	//create object factory
	m_factory = new ObjectFactory(&m_eventHandler);

	//create debug object
	m_debug = new Debug(_pd3dDevice);

	//create GameData struct and populate its pointers
	m_GD = new GameData;
	m_GD->m_GS = GS_PLAY_MAIN_CAM;
	m_GD->m_eventHandler = &m_eventHandler;
	m_GD->m_collisionGroup = &m_collisionGroup;
	m_GD->m_factory = m_factory;
	m_GD->m_Device = _pd3dDevice;
	m_GD->m_ImmediateContext = pd3dImmediateContext;
	m_GD->m_selectedButton = nullptr;
	m_GD->m_debug = m_debug;

	//Create behaviour manager
	m_behaviourManager = new BehaviourManager(m_GD);

	m_GD->m_behaviorManager = m_behaviourManager;

	//set up DirectXTK Effects system
	m_fxFactory = new EffectFactory(_pd3dDevice);

	//Tell the fxFactory to look to the correct build directory to pull stuff in from
#ifdef DEBUG
	((EffectFactory*)m_fxFactory)->SetDirectory(L"../Debug");
#else
	((EffectFactory*)m_fxFactory)->SetDirectory(L"../Release");
#endif

	// Create other render resources here
	m_states = new CommonStates(_pd3dDevice);

	//init render system for VBGOs
	VBGO::Init(_pd3dDevice);

	//find how big my window is to correctly calculate my aspect ratio
	RECT rc;
	GetClientRect(m_hWnd, &rc);
	UINT width = rc.right - rc.left;
	UINT height = rc.bottom - rc.top;
	float AR = (float)width / (float)height;

	//create a base camera
	m_cam = new Camera(0.25f * XM_PI, AR, 1.0f, 10000.0f, Vector3::UnitY , Vector3::Zero);
	m_cam->SetPos(Vector3(0.0f, 100.0f, 100.0f)); 
	m_GameObjects.push_back(m_cam);

	//create a base light
	m_light = new Light(Vector3(0.0f, 100.0f, 160.0f), Color(1.0f, 1.0f, 1.0f, 1.0f), Color(0.4f, 0.1f, 0.1f, 1.0f));
	m_GameObjects.push_back(m_light);

	//create DrawData struct and populate its pointers
	m_DD = new DrawData;
	m_DD->m_pd3dImmediateContext = nullptr;
	m_DD->m_states = m_states;
	m_DD->m_cam = m_cam;
	m_DD->m_light = m_light;

	//Level
	//m_level = m_factory->CreateGameObject<Level>(m_GD, _pd3dDevice, "Data/Levels/testing", "Data/Objects/Explosion", "Test Level", 10);
	m_level = m_factory->LoadLevelFromFile(m_GD, _pd3dDevice, "TestLevel");
	//add all created objects to update/draw system
	m_GameObject2Ds = &m_factory->GetGameObject2Ds();

	m_behaviourManager->_level = m_level;

	//Draw the render target texture
	m_level->DrawRenderTarget(m_DD2D);
}

Game::~Game()
{
	//tidy up VBGO render system
	VBGO::CleanUp();

	//Clean the input stuff
	Input::End();

	//get rid of the game objects here
	for (auto it = m_GameObjects.begin(); it != m_GameObjects.end(); it++)
	{
		delete (*it);
	}
	m_GameObjects.clear();

	//clear away CMO render system
	delete m_states;
	delete m_fxFactory;

	// delete our stuff
	delete m_behaviourManager;
	delete m_factory;
	delete m_debug;

	//delete Game Data & Draw Data
	delete m_GD;
	delete m_DD;
	delete m_DD2D;
}

bool Game::Update()
{
	//Update input
	if (!Input::Update())
	{
		return false;
	}


	//calculate frame time-step dt for passing down to game objects
	DWORD currentTime = GetTickCount();


	// looking at capping at 30FPS
	float dt = (float)(currentTime - m_playTime);

	if (dt < 1000.0f / 60.0f)
	{
		int diff = 1000.0f / 60.0f - dt;
		this_thread::sleep_for(std::chrono::milliseconds(diff));

		currentTime = GetTickCount();
		dt = (float)(currentTime - m_playTime);
	}

	dt = 1000.0f / 60.0f;

	m_playTime = currentTime;

	m_GD->m_dt = dt / 1000.0f;


	Vector2 mousePos = Vector2(Input::GetMouseX(), Input::GetMouseY());

	m_debug->drawCross(mousePos);

	/*GameObject2D* obj = m_GD->m_collisionGroup->PointCast(mousePos);
	if (obj->GetTag() == "Button")
	{
		Button* butt = (Button*)obj;
		m_GD->m_debug->drawBox(butt->GetPos() - butt->GetSize() * 0.5f, butt->GetPos() + butt->GetSize() * 0.5f);
	}*/

	
	//update all objects
	for (auto it = m_GameObjects.begin(); it != m_GameObjects.end(); it++)
	{
		(*it)->Tick( m_GD );
	}
	for (auto it = m_GameObject2Ds->cbegin(); it != m_GameObject2Ds->cend(); it++)
	{
		(*it)->Tick();
	}

	//delete objects marked as deleted
	m_factory->DoDeletion();

	//update collision
	m_GD->m_collisionGroup->Update(&m_eventHandler);

	//Process queued events on the eventHandler, including scripts that listen out for collisions
	m_eventHandler.ProcessEvents();

	// test for drawBox (graphical debug)
	//m_GD->m_debug->drawBox(Vector2(100,150),Vector2(150,100));

	return true;
}

void Game::Render(ID3D11DeviceContext* _pd3dImmediateContext)
{
	//set immediate context of the graphics device
	m_DD->m_pd3dImmediateContext = _pd3dImmediateContext;
	m_GD->m_ImmediateContext = _pd3dImmediateContext;

	//update the constant buffer for the rendering of VBGOs
	VBGO::UpdateConstantBuffer(m_DD);


	//draw all objects
	for (auto it = m_GameObjects.begin(); it != m_GameObjects.end(); it++)
	{
		(*it)->Draw(m_DD);
	}


	//Cut out the explosions from the level
	m_level->DrawTerrainElements(m_DD2D);

	// Draw sprite batch stuff 
	m_DD2D->m_Sprites->Begin();
	for (auto it = m_GameObject2Ds->crbegin(); it != m_GameObject2Ds->crend(); it++)
	{
		(*it)->Draw(m_DD2D);
	}

	m_debug->draw(m_DD2D);

	m_DD2D->m_Sprites->End();


	//drawing text screws up the Depth Stencil State, this puts it back again!
	_pd3dImmediateContext->OMSetDepthStencilState(m_states->DepthDefault(), 0);
}

