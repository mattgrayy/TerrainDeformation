#pragma once
#include "ColliderBox.h"
#include "DrawData2D.h"

class Debug{

public:
	Debug(ID3D11Device* _D);
	~Debug() = default;

	// draw a line from two points (fredwina and timothy)
	void drawLine(Vector2 fredwina, Vector2 timothy);
	void draw(DrawData2D* _DD);
	void drawBox(Vector2 bottomLeft, Vector2 topRight);
	void drawCross(Vector2 point, float radius = 10.0f);
	

private:
	ID3D11ShaderResourceView* m_pTextureRV;

	vector<pair<Vector2, Vector2>> m_lines;

};