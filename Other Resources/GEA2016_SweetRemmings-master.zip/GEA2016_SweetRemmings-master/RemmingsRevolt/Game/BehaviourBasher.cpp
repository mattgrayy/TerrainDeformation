#include "BehaviourBasher.h"
#include "GameData.h"
#include "BehaviourManager.h"
#include "Level.h"

BehaviourBasher::BehaviourBasher(GameData* _GD) 
	: Behaviour(_GD), m_bashTimer(-0.1f)
{
}


BehaviourBasher::~BehaviourBasher()
{
}

void BehaviourBasher::OnHitWall(Lemming* lemming)
{
	if (m_bashTimer < 0.0f)
	{
		m_bashTimer = 0.0f;
	}
	else if (m_bashTimer > 0.5f)
	{
		lemming->resetBehaviour();
		return;
	}

	lemming->SetGrounded(false);

	m_GD->m_behaviorManager->_level->MakeHole(Vector2(lemming->GetPos().x + (lemming->GetColBox()->GetSize().x / 4), lemming->GetPos().y), lemming->GetColBox()->GetSize().y * 1.1f);
	m_GD->m_behaviorManager->_level->MakeHole(Vector2(lemming->GetPos().x - (lemming->GetColBox()->GetSize().x / 4), lemming->GetPos().y), lemming->GetColBox()->GetSize().y * 1.1f);
	m_GD->m_behaviorManager->_level->MakeHole(Vector2(lemming->GetPos().x + (lemming->GetColBox()->GetSize().x/1.01f), (lemming->GetPos().y + lemming->GetColBox()->GetSize().y / 4)), lemming->GetColBox()->GetSize().y / 2);
	m_GD->m_behaviorManager->_level->MakeHole(Vector2(lemming->GetPos().x - (lemming->GetColBox()->GetSize().x/1.01f), (lemming->GetPos().y + lemming->GetColBox()->GetSize().y / 4)), lemming->GetColBox()->GetSize().y / 2);
}

void BehaviourBasher::Tick(Lemming* lemming)
{
	OnFalling(lemming);
	lemming->GetPos().y += m_GD->m_dt * lemming->GetVelocity().y;

	if (lemming->GetGrounded())
	{
		lemming->GetPos().x += m_GD->m_dt * lemming->GetVelocity().x;
	}
	lemming->SetGrounded(false);

	if (m_bashTimer >= 0.0f)
	{
		m_bashTimer += m_GD->m_dt;
	}
}