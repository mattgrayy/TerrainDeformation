#pragma once

#include <unordered_set>
#include "Collider.h"
#include "EventHandler.h"

class GameObject2D;

using namespace std;



class TriggerEvent
{
public:
	TriggerEvent(GameObject2D* _obj1, GameObject2D* _obj2, Collider* _col1, Collider* _col2)
		: obj1(_obj1), obj2(_obj2), col1(_col1), col2(_col2)
	{
	}

	GameObject2D* obj1;
	GameObject2D* obj2;
	Collider* col1;
	Collider* col2;
};

class CollisionEvent : public TriggerEvent
{
public:
	CollisionEvent(GameObject2D* _obj1, GameObject2D* _obj2, Collider* _col1, Collider* _col2, Vector2 _movement)
		: TriggerEvent(_obj1, _obj2, _col1, _col2), movement(_movement)
	{
	}
	Vector2 movement;
};

class Collision
{
	//Friends with colliders so they can add and remove themselves in its constructor and destructor
	friend class Collider;

public:
	Collision();
	~Collision();

	void Update(EventHandler* eventHandler);

	GameObject2D* PointCast(const Vector2& point) const;

private:

	bool CheckTagsCollidesWith(const Collider* const col1, const Collider* const col2) const;

	void AddCollider(Collider* col);
	void RemoveCollider(Collider* col);

	unordered_set<Collider*> m_colliders;
};

