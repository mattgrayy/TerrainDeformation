#ifndef _GAME_OBJECT_2D_H_
#define _GAME_OBJECT_2D_H_

//=================================================================
//the base Game Object 2D
//=================================================================
#include <d3d11_1.h>
#include "SimpleMath.h"
#include <string>

using namespace DirectX;
using namespace SimpleMath;
using namespace std;

struct GameData;
struct DrawData2D;

class GameObject2D
{
public:
	GameObject2D(GameData* _GD);
	virtual ~GameObject2D(){};

	virtual void Tick();
	virtual void Draw(DrawData2D* _DD)=0;

	const Vector2& GetPos() { return m_pos; }
	const float& GetRot() { return m_rotation; }

	void SetPos(Vector2 _pos){ m_pos = _pos; }
	void SetRot(float _rot){ m_rotation = _rot; }
	void SetColour(Color _colour){ m_colour = _colour; }
	void SetScale(Vector2 _scale){ m_scale = _scale; }
	void SetScale(float _scale){ m_scale = _scale * Vector2::One; }
	void SetOrigin(Vector2 _origin){ m_origin = _origin; }
	void SetTag(string _tag){ m_tag = _tag; }
	const string& GetTag(){ return m_tag; }

protected:
	bool isAlive;

	Vector2 m_pos;
	float m_rotation;
	Vector2 m_scale;
	Color m_colour;
	Vector2 m_origin;

	string m_tag = "";

	GameData* m_GD;
};


#endif