#pragma once

#include "Button.h"

class ButtonSpawnRate : public Button
{
public:
	ButtonSpawnRate(GameData* _GD, string _filename, ID3D11Device* _D, int posIndex, bool isAdder);
	~ButtonSpawnRate();

	virtual void Tick() override;

	virtual void OnClicked() override;

private:
	bool m_isAdder;
};

