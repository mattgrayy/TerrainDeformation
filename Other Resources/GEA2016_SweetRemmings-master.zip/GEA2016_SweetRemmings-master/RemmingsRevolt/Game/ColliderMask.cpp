#include "ColliderMask.h"
#include "Collision.h"
//#include <iostream>


ColliderMask::ColliderMask(Vector2* position, GameObject2D* gameObj, Collision* collisionGroup, RenderTarget* renderTarget, bool isStatic, bool isTrigger)
	: Collider(position, gameObj, collisionGroup, isStatic, isTrigger), m_rendTarg(renderTarget)
{
	
}


ColliderMask::~ColliderMask()
{
}


bool ColliderMask::Intersects(const Collider* const col, Vector2& moveOffset) const
{
	return col->Intersects(this, moveOffset);
}
bool ColliderMask::Intersects(const Vector2& point, Vector2& moveOffset) const
{
	int x = (int)roundf(point.x - m_pos->x);
	int y = (int)roundf(point.y - m_pos->y);

	Color* color = m_rendTarg->GetPixel(x, y);

	//cout << color->A() << endl;

	if (color->A() < 0.1f)
	{
		//Point is air, return false
		return false;
	}

	//if (y > 196)
	//{
	//	color->A();
	//}

	//If we are a trigger, dont bother calculating the moveOffset
	if (m_isTrigger)
		return true;

	const int width = 11; //These probably should be odd numbers

	//cout << "Start" << endl;

	//we need to find the closest point to this one that is empty
	for (int ix = 0; ix < width; ix++)
	{
		int dx = (ix % 2 == 0 ? ix : -ix - 1) / 2;
		//dx will be as follows:
		//ix = 0: 0
		//ix = 1: -1
		//ix = 2: 1
		//ix = 3: -2
		//ix = 4: 2
		//ix = 5: -3 etc
		for (int iy = 0; iy < width; iy++)
		{
			//int dy = (iy % 2 == 0 ? iy : -iy - 1) / 2;
			//dy follows same rules as dx

			//Search vertically upwards first
			int dy = iy <= 5 ? -iy : iy - 5;

			//cout << "(" << dx << ", " << dy << ")  ";

			Color* color = m_rendTarg->GetPixel(x + dx, y + dy);

			//cout << color->R() << ", " << color->G() << ", " << color->B() << ", " << color->A() << endl;

			if (color->A() < 0.1f)
			{
				//This space is empty, set the offset to this, and return true
				moveOffset = Vector2(-dx, point.y - m_pos->y - y - dy);
				//moveOffset = Vector2(point.x - m_pos->x - x - dx, point.y - m_pos->y - y - dy);
				return true;
			}
		}
	}

	//Were inside something, but we cant see a way out!
	//Push ourselfs upwards
	moveOffset = Vector2(0, 1);
	return true;
}
bool ColliderMask::Intersects(const ColliderBox* const col, Vector2& moveOffset) const
{
	return false;
}
bool ColliderMask::Intersects(const ColliderMask* const col, Vector2& moveOffset) const
{
	return false;
}
