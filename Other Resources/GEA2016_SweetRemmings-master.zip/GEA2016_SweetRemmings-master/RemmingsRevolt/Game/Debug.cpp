#include "Debug.h"
#include "WICTextureLoader.h"
#include "helper.h"

Debug::Debug(ID3D11Device* _D)
{
	string fullfilename =
	#if DEBUG
			"../Debug/"
	#else
			"../Release/"
	#endif
		+ string("Data/Objects/Debug_Pixel") + ".png";
	HRESULT hr = CreateWICTextureFromFile(_D, Helper::charToWChar(fullfilename.c_str()), nullptr, &m_pTextureRV);

	//this nasty thing is required to find out the size of this image!
	ID3D11Resource *pResource;
	D3D11_TEXTURE2D_DESC Desc;
	m_pTextureRV->GetResource(&pResource);
	((ID3D11Texture2D *)pResource)->GetDesc(&Desc);
}

void Debug::drawLine(Vector2 fredwina, Vector2 timothy)
{
	m_lines.push_back(pair < Vector2, Vector2 >(fredwina, timothy));
}

void Debug::draw(DrawData2D* _DD)
{
	for (auto it = m_lines.begin(); it != m_lines.end(); ++it)
	{
		Vector2 fredwina = it->first;
		Vector2 timothy = it->second;
		_DD->m_Sprites->Draw(m_pTextureRV, (fredwina + timothy) / 2, nullptr, Color(1,1,1,1), atan2f(timothy.y - fredwina.y, timothy.x - fredwina.x), Vector2(0.5, 0.5), Vector2(Vector2::Distance(fredwina, timothy), 1), SpriteEffects_None);
	}
	
	m_lines.clear();
}

void Debug::drawBox(Vector2 bottomLeft, Vector2 topRight)
{
	Vector2 bottomRight = Vector2(topRight.x, bottomLeft.y);
	Vector2 topLeft = Vector2(bottomLeft.x, topRight.y);
	drawLine(bottomLeft, bottomRight);
	drawLine(bottomRight, topRight);
	drawLine(topRight, topLeft);
	drawLine(topLeft, bottomLeft);
}


void Debug::drawCross(Vector2 point, float radius)
{
	drawLine(Vector2(point.x - radius - 1, point.y), Vector2(point.x + radius, point.y));
	drawLine(Vector2(point.x, point.y - radius - 1), Vector2(point.x, point.y + radius));
}