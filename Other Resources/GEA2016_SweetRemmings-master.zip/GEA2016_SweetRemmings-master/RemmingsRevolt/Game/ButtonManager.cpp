#include "ButtonManager.h"
#include "BehaviourManager.h"
#include "GameData.h"

#include "Button.h"
#include "ButtonBehaviour.h"
#include "ButtonSpawnRate.h"

ButtonManager::ButtonManager(GameData* _GD, BehaviourCount* _behaveCounts)
{
	///create all buttons
	//spawn rate down button
	Button* spawnRateDnBut = (Button*)_GD->m_factory->CreateGameObject<ButtonSpawnRate>(_GD, "Data/Objects/Behaviour_Blank", _GD->m_Device, 0, false);
	m_buttons.push_back(spawnRateDnBut);
	//spawn rate up button
	Button* spawnRateUpBut = (Button*)_GD->m_factory->CreateGameObject<ButtonSpawnRate>(_GD, "Data/Objects/Behaviour_Blank", _GD->m_Device, 1, true);
	m_buttons.push_back(spawnRateUpBut);
	//climber button
	Button* climberBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Climby_off", _GD->m_Device, BehaviourType::BehaviourFloaterT, _behaveCounts->m_climber, 2);
	m_buttons.push_back(climberBut);
	//floater button
	Button* floaterBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Floaty_off", _GD->m_Device, BehaviourType::BehaviourFloaterT, _behaveCounts->m_floater, 3);
	m_buttons.push_back(floaterBut);
	//bomber button
	Button* bomberBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Bomby_off", _GD->m_Device, BehaviourType::BehaviourBomberT, _behaveCounts->m_bomber, 4);
	m_buttons.push_back(bomberBut);
	//blocker button
	Button* blockerBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Blocky_off", _GD->m_Device, BehaviourType::BehaviourBlockerT, _behaveCounts->m_blocker, 5);
	m_buttons.push_back(blockerBut);
	//builder button
	Button* builderBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Buildy_off", _GD->m_Device, BehaviourType::BehaviourBuilderT, _behaveCounts->m_builder, 6);
	m_buttons.push_back(builderBut);
	//basher button
	Button* basherBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Bashy_off", _GD->m_Device, BehaviourType::BehaviourBasherT, _behaveCounts->m_basher, 7);
	m_buttons.push_back(basherBut);
	//miner button
	Button* minerBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Miney_off", _GD->m_Device, BehaviourType::BehaviourMinerT, _behaveCounts->m_miner, 8);
	m_buttons.push_back(minerBut);
	//digger button
	Button* diggerBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Diggy_off", _GD->m_Device, BehaviourType::BehaviourDiggerT, _behaveCounts->m_digger, 9);
	m_buttons.push_back(diggerBut);
	//walker button
	Button* walkerBut = (Button*)_GD->m_factory->CreateGameObject<ButtonBehaviour>(_GD, "Data/Objects/Behaviour_Blank", _GD->m_Device, BehaviourType::BehaviourBaseT, 100, 10);
	m_buttons.push_back(walkerBut);
	//nuke button
	Button* nukeBut = _GD->m_factory->CreateGameObject<Button>(_GD, "Data/Objects/Behaviour_Blank", _GD->m_Device, 11);
	m_buttons.push_back(nukeBut);
}

ButtonManager::~ButtonManager()
{
	
}