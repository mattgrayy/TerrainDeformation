#ifndef _IMAGE_GO_2D_H_
#define _IMAGE_GO_2D_H_
#include "GameObject2D.h"

#include "ColliderBox.h"
#include "SpriteBatch.h"

class ImageGO2D :public GameObject2D
{
public:
	ImageGO2D(GameData* _GD, string _fileName, ID3D11Device* _D);
	virtual ~ImageGO2D();

	virtual void Tick();
	virtual void Draw(DrawData2D* _DD);

	const Vector2& GetSize() { return m_size; }

	void FlipImageHoriz();
protected:
	ID3D11ShaderResourceView* m_pTextureRV;

	Vector2 m_size;

	SpriteEffects imageEffect;
};

#endif