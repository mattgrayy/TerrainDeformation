#include "Button.h"
#include "GameData.h"
#include "DrawData2D.h"
#include "Input.h"
#include <iostream>
#include "BehaviourManager.h"
#include "Level.h"

Button::Button(GameData* _GD, string _filename, ID3D11Device* _D, int posIndex)

	: ImageGO2D(_GD, _filename, _D)
{
	m_tag = "Button";

	float posX = posIndex * 40 + (m_size.x / 2);
	float posY = 600 - (m_size.y / 2);
	m_pos = Vector2(posX, posY);

	m_butCollider = new ColliderBox(&m_pos, this, _GD->m_collisionGroup, m_size, true, true);

	m_textObj = _GD->m_factory->CreateGameObject<TextGO2D>(_GD, &m_textDpl);//text object
	m_textObj->SetPos(Vector2(m_pos.x - 15, m_pos.y - 30));

}

Button::~Button()
{
	delete m_butCollider;
}

void Button::Tick()
{
	if (Input::GetMouseButtonDown(0))
	{
		Vector2 mousePos = Vector2(Input::GetMouseX(), Input::GetMouseY());
		//if (m_GD->m_collisionGroup->PointCast(mousePos) == this)
		Vector2 notInUse;
		if (m_butCollider->Intersects(mousePos, notInUse))
		{
			std::cout << "Buttom pressed" << endl;
			OnClicked();
		}
	}
}

void Button::OnClicked()
{
	m_GD->m_behaviorManager->_level->killAllLemmings();
}

void Button::SetText(int i)
{
	char temp[10];
	itoa(i, temp, 10);
	m_textDpl = temp;
}