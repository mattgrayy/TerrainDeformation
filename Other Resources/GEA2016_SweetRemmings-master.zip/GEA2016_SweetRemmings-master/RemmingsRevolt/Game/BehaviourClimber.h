#pragma once
#include "Behaviour.h"
class BehaviourClimber :
	public Behaviour
{
public:
	BehaviourClimber(GameData* _GD);
	virtual ~BehaviourClimber();

	virtual void OnHitWall(Lemming* lemming);

	virtual void Tick(Lemming* lemming);

private:
	bool m_climbing = false;
};

