#include "ColliderBox.h"


ColliderBox::ColliderBox(Vector2* position, GameObject2D* gameObj, Collision* collisionGroup, Vector2 size, bool isStatic, bool isTrigger)
	: Collider(position, gameObj, collisionGroup, isStatic, isTrigger), m_size(size)
{
}


ColliderBox::~ColliderBox()
{
}


bool ColliderBox::Intersects(const Collider* const col, Vector2& moveOffset) const
{
	return col->Intersects(this, moveOffset);
}
bool ColliderBox::Intersects(const Vector2& point, Vector2& moveOffset) const
{
	float halfSizeX = m_size.x / 2;
	float halfSizeY = m_size.y / 2;
	if (point.x >= m_pos->x - halfSizeX && point.x < m_pos->x + halfSizeX &&
		point.y >= m_pos->y - halfSizeY && point.y < m_pos->y + halfSizeY)
	{
		if (point.x < m_pos->x)
		{
			moveOffset.x = point.x - (m_pos->x - halfSizeX);
		}
		else
		{
			moveOffset.x = point.x - (m_pos->x + halfSizeX);
		}

		return true;
	}

	return false;
}
bool ColliderBox::Intersects(const ColliderBox* const col, Vector2& moveOffset) const
{
	return
		m_pos->x < col->m_pos->x + col->m_size.x &&
		m_pos->x + m_size.x > col->m_pos->x &&
		m_pos->y < col->m_pos->y + col->m_size.y &&
		m_pos->y + m_size.y > col->m_pos->y;

}
bool ColliderBox::Intersects(const ColliderMask* const col, Vector2& moveOffset) const
{
	return false;
}


void ColliderBox::SetSize(Vector2& const size)
{
	m_size = size;
}
const Vector2& ColliderBox::GetSize() const
{
	return m_size;
}