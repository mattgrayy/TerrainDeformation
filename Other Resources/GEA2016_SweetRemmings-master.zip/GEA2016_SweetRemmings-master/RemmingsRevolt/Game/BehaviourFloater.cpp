#include "BehaviourFloater.h"


BehaviourFloater::BehaviourFloater(GameData* _GD)
	: Behaviour(_GD)
{
}


BehaviourFloater::~BehaviourFloater()
{
}

void BehaviourFloater::Init(Lemming* lemming)
{
	m_fallTimer = 0.0f;
}

void BehaviourFloater::OnHitFloor(Lemming* lemming)
{
	lemming->SetGrounded(true);
}

void BehaviourFloater::Tick(Lemming* lemming)
{
	lemming->GetPos().y += m_GD->m_dt * (lemming->GetVelocity().y /2);

	if (lemming->GetGrounded())
	{
		lemming->GetPos().y += m_GD->m_dt * (lemming->GetVelocity().y / 2);
		lemming->GetPos().x += m_GD->m_dt * lemming->GetVelocity().x;
	}
	lemming->SetGrounded(false);
}