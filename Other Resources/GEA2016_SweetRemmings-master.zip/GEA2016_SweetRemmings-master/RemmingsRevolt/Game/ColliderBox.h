#pragma once
#include "Collider.h"
class ColliderBox : public Collider
{
public:
	ColliderBox(Vector2* position, GameObject2D* gameObj, Collision* collisionGroup, Vector2 size, bool isStatic = false, bool isTrigger = false);
	virtual ~ColliderBox();

	void SetSize(Vector2& const size);
	const Vector2& GetSize() const;

	bool Intersects(const Vector2& point, Vector2& moveOffset) const override;
	bool Intersects(const Collider* const col, Vector2& moveOffset) const override;
	bool Intersects(const ColliderBox* const col, Vector2& moveOffset) const override;
	bool Intersects(const ColliderMask* const col, Vector2& moveOffset) const override;

private:
	Vector2 m_size;
};

