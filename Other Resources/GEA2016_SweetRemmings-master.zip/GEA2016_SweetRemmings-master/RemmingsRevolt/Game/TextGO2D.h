#ifndef _TEXT_GO_2D_H_
#define _TEXT_GO_2D_H_
#include "GameObject2D.h"
#include "ColliderPoint.h"

class TextGO2D :public GameObject2D
{
public:
	TextGO2D(GameData* _GD, string* _text);

	virtual void Tick();
	virtual void Draw(DrawData2D* _DD);
protected:
	string* m_text;
};

#endif