#pragma once

#include "Collider.h"
#include "RenderTarget.h"

class ColliderMask : public Collider
{
public:
	ColliderMask(Vector2* position, GameObject2D* gameObj, Collision* collisionGroup, RenderTarget* renderTarget, bool isStatic = false, bool isTrigger = false);
	~ColliderMask();

	bool Intersects(const Vector2& point, Vector2& moveOffset) const override;
	bool Intersects(const Collider* const col, Vector2& moveOffset) const override;
	bool Intersects(const ColliderBox* const col, Vector2& moveOffset) const override;
	bool Intersects(const ColliderMask* const col, Vector2& moveOffset) const override;

private:
	RenderTarget* m_rendTarg;
	ID3D11DeviceContext* m_deviceContext;
};

