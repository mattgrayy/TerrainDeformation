#pragma once
#include "ImageGO2D.h"
class StaticObject :
	public ImageGO2D
{
public:
	StaticObject(GameData* _GD, ID3D11Device* _D, string _fileName, Vector2 _pos);
	virtual ~StaticObject();
};

