#pragma once

#include "AllBehaviours.h"
#include "GameData.h"
#include <vector>

class BehaviourManager
{
public:
	BehaviourManager(GameData* _GD);
	~BehaviourManager();

	Behaviour* requestBehaviour(BehaviourType _type, GameData* _GD);

	Behaviour* _behDefault;
	BehaviourBasher* _behBasher;
	BehaviourBlocker* _behBlocker;
	BehaviourBomber* _behBomber;
	BehaviourBuilder* _behBuilder;
	BehaviourClimber* _behClimber;
	BehaviourDigger* _behDigger;
	BehaviourFloater* _behFloater;
	BehaviourMiner* _behMiner;

	Level* _level;
};

