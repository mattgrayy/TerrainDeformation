#include "Trap.h"
#include "Lemming.h"

Trap::Trap(GameData* _GD, ID3D11Device* _D, string _fileName, Vector2 _pos)
	: TriggerObject(_GD, _D, _fileName, _pos)
{
	m_tag = "Trap";
}

void Trap::OnTriggerHit(const TriggerEvent& evnt)
{
	if (evnt.obj1 != this)
	{
		return;
	}
	if (evnt.obj2->GetTag() == "Lemming")
	{
		static_cast<Lemming*>(evnt.obj2)->kill();
	}
}