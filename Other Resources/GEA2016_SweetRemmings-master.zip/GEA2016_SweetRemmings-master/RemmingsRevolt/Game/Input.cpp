#include "Input.h"

HWND* Input::m_hWnd = nullptr;

IDirectInput8* Input::m_pDirectInput = nullptr;
IDirectInputDevice8* Input::m_pKeyboard = nullptr;
IDirectInputDevice8* Input::m_pMouse = nullptr;

unsigned char Input::m_keyboardState[256];
unsigned char Input::m_prevKeyboardState[256];

int Input::m_mousePosX = 0;
int Input::m_mousePosY = 0;

DIMOUSESTATE Input::m_mouseState;
bool Input::m_prevMouse[4];

const map<string, int> Input::inputStrings = createInputStringMap();

void Input::Start(HINSTANCE _hInstance, HWND* _hWnd) {

	m_pDirectInput = nullptr;
	m_pKeyboard = nullptr;
	m_pMouse = nullptr;
	m_hWnd = _hWnd;

	//Direct Input Stuff
	HRESULT hr;
	hr = DirectInput8Create(_hInstance, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&m_pDirectInput, NULL);

	//Keyboard
	hr = m_pDirectInput->CreateDevice(GUID_SysKeyboard, &m_pKeyboard, NULL);
	hr = m_pKeyboard->SetDataFormat(&c_dfDIKeyboard);
	hr = m_pKeyboard->SetCooperativeLevel(*m_hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE);

	//Mouse
	hr = m_pDirectInput->CreateDevice(GUID_SysMouse, &m_pMouse, NULL);
	hr = m_pMouse->SetDataFormat(&c_dfDIMouse);
	hr = m_pMouse->SetCooperativeLevel(*m_hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE);
}

bool Input::Update() {
	//read mouse and keyboard state
	ReadKeyboard();
	ReadMouse();

	//if esc is pressed, quit
	if (m_keyboardState[DIK_ESCAPE] & 0x80)
	{
		return false;
	}

	//toggle the gamestate when space is pressed
	//if ((m_keyboardState[DIK_SPACE] & 0x80) && !(m_prevKeyboardState[DIK_SPACE] & 0x80)) {
		//toggle the state
		//m_GameData->curState = m_GameData->curState == PLAY_MAIN_CAM ? PLAY_TPS_CAM : PLAY_MAIN_CAM;
	//}

	//Lock the cursor to the center of the window
	RECT window;
	GetWindowRect(*m_hWnd, &window);

	return true;
}

void Input::End() {
	//tidy away Direct Input Stuff
	if (m_pKeyboard)
	{
		m_pKeyboard->Unacquire();
		m_pKeyboard->Release();
		m_pKeyboard = 0;
	}

	if (m_pMouse)
	{
		m_pMouse->Unacquire();
		m_pMouse->Release();
		m_pMouse = 0;
	}

	if (m_pDirectInput)
		m_pDirectInput->Release();
}


bool Input::GetButton(const string& str)
{
	auto pair = inputStrings.find(str);
	if(pair == inputStrings.end()) {
		return false;
	}

	return m_keyboardState[pair->second] & 0x80;
}
bool Input::GetButtonUp(const string& str)
{
	auto pair = inputStrings.find(str);
	if(pair == inputStrings.end()) {
		return false;
	}

	return !(m_keyboardState[pair->second] & 0x80) && (m_prevKeyboardState[pair->second] & 0x80);
}
bool Input::GetButtonDown(const string& str)
{
	auto pair = inputStrings.find(str);
	if(pair == inputStrings.end()) {
		return false;
	}

	return (m_keyboardState[pair->second] & 0x80) && !(m_prevKeyboardState[pair->second] & 0x80);
}

float Input::GetAxis(const string& positive, const string& negative)
{
	return (GetButton(positive) ? 1.0f : 0.0f) - (GetButton(negative) ? 1.0f : 0.0f);
}

int Input::GetMouseX()
{
	//return m_mouseState.lX;
	return m_mousePosX;
}
int Input::GetMouseY()
{
	//return m_mouseState.lY;
	return m_mousePosY;
}

bool Input::GetMouseButton(int buttonIdx)
{
	return m_mouseState.rgbButtons[buttonIdx];
}
bool Input::GetMouseButtonUp(int buttonIdx)
{
	return !m_mouseState.rgbButtons[buttonIdx] && m_prevMouse[buttonIdx];
}
bool Input::GetMouseButtonDown(int buttonIdx)
{
	return m_mouseState.rgbButtons[buttonIdx] && !m_prevMouse[buttonIdx];
}



bool Input::ReadKeyboard()
{
	//copy over old keyboard state
	memcpy(m_prevKeyboardState, m_keyboardState, sizeof(unsigned char) * 256);

	//clear out state
	ZeroMemory(&m_keyboardState, sizeof(m_keyboardState));

	// Read the keyboard device.
	HRESULT hr = m_pKeyboard->GetDeviceState(sizeof(m_keyboardState), (LPVOID)&m_keyboardState);

	if (FAILED(hr))
	{
		// If the keyboard lost focus or was not acquired then try to get control back.
		if ((hr == DIERR_INPUTLOST) || (hr == DIERR_NOTACQUIRED))
		{
			m_pKeyboard->Acquire();
		}
		else
		{
			return false;
		}
	}
	return true;
}

bool Input::ReadMouse()
{
	m_prevMouse[0] = m_mouseState.rgbButtons[0];
	m_prevMouse[1] = m_mouseState.rgbButtons[1];
	m_prevMouse[2] = m_mouseState.rgbButtons[2];
	m_prevMouse[3] = m_mouseState.rgbButtons[3];
	
	//clear out previous state
	ZeroMemory(&m_mouseState, sizeof(DIMOUSESTATE));

	//Get the cursor position
	POINT curPos;
	if (GetCursorPos(&curPos))
	{
		RECT rc;
		GetClientRect(*m_hWnd, &rc);
		float width = rc.right - rc.left;
		float height = rc.bottom - rc.top;

		ScreenToClient(*m_hWnd, &curPos);
		m_mousePosX = (int)(curPos.x * (800.0f / width));
		m_mousePosY = (int)(curPos.y * (600.0f / height));
	}


	// Read the mouse device.
	HRESULT hr = m_pMouse->GetDeviceState(sizeof(DIMOUSESTATE), (LPVOID)&m_mouseState);

	if (FAILED(hr))
	{
		// If the mouse lost focus or was not acquired then try to get control back.
		if ((hr == DIERR_INPUTLOST) || (hr == DIERR_NOTACQUIRED))
		{
			m_pMouse->Acquire();
		}
		else
		{
			return false;
		}
	}
	return true;
}
