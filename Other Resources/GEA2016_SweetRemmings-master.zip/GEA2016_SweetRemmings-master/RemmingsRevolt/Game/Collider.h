#pragma once

#include <SimpleMath.h>
#include <unordered_set>
#include <string>

using namespace DirectX::SimpleMath;
using namespace std;

class GameObject2D;
class Collision;
class ColliderBox;
class ColliderMask;
class ColliderPoint;

class Collider
{
	friend class Collision;
public:
	Collider(Vector2* position, GameObject2D* gameObj, Collision* collisionGroup, bool isStatic = false, bool isTrigger = false);
	virtual ~Collider();

	void AddCollideTag(const string& tag);

	template<typename... Args>
	void AddCollideTag(const string& tag, const Args&... args)
	{
		AddCollideTag(tag);
		AddCollideTag(args...);
	}

	void RemoveCollideTag(const string& tag);

	template<typename... Args>
	void RemoveCollideTag(const string& tag, const Args&... args)
	{
		RemoveCollideTag(tag);
		RemoveCollideTag(args...);
	}

	void CollideWithAll();

	virtual bool Intersects(const Vector2& point, Vector2& moveOffset) const = 0;
	virtual bool Intersects(const Collider* const col, Vector2& moveOffset) const = 0;
	virtual bool Intersects(const ColliderBox* const col, Vector2& moveOffset) const = 0;
	virtual bool Intersects(const ColliderMask* const col, Vector2& moveOffset) const = 0;
	virtual bool Intersects(const ColliderPoint* const col, Vector2& moveOffset) const;

	bool GetIsTrigger() { return m_isTrigger; }
	void SetIsTrigger(bool trigger) { m_isTrigger = trigger; }
	bool GetIsStatic() { return m_isStatic; }
	void SetIsStatic(bool stat) { m_isStatic = stat; }

protected:
	bool m_isStatic;
	bool m_isTrigger;
	Vector2* m_pos;
	GameObject2D* m_gameObject;
	Collision* m_collisionGroup;

	unordered_set<string> m_collidesWith;
};

