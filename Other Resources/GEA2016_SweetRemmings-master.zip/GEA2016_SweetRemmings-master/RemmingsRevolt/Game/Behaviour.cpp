#include "Behaviour.h"

#include <iostream>

Behaviour::Behaviour(GameData* _GD) 
	: m_GD(_GD), m_fallTimer(0.0f)
{
}

Behaviour::~Behaviour()
{
}

void Behaviour::Init(Lemming* lemming)
{

}

void Behaviour::OnHitWall(Lemming* lemming)
{
	lemming->GetVelocity().x = -lemming->GetVelocity().x;
	lemming->FlipImageHoriz();
}

void Behaviour::OnHitFloor(Lemming* lemming)
{
	lemming->SetGrounded(true);
	if (m_fallTimer > 3.0f)
	{
		lemming->kill();
	}
	m_fallTimer = 0.0f;
}

void Behaviour::OnFalling(Lemming* lemming)
{
	m_fallTimer += m_GD->m_dt;
}

void Behaviour::Tick(Lemming* lemming)
{
	OnFalling(lemming);
	lemming->GetPos().y += m_GD->m_dt * lemming->GetVelocity().y;

	if (lemming->GetGrounded())
	{
		lemming->GetPos().x += m_GD->m_dt * lemming->GetVelocity().x;
	}
	lemming->SetGrounded(false);
}