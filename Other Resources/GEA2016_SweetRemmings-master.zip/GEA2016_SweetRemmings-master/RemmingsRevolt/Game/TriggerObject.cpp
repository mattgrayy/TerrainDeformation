#include "TriggerObject.h"
#include "GameData.h"

TriggerObject::TriggerObject(GameData* _GD, ID3D11Device* _D, string _fileName, Vector2 _pos)
	: StaticObject(_GD, _D, _fileName, _pos)
{
	m_collider = new ColliderBox(&m_pos, this, _GD->m_collisionGroup, m_size, true, true);
	_GD->m_eventHandler->StartListen(this, &TriggerObject::OnTriggerHit);
}


TriggerObject::~TriggerObject()
{
	m_GD->m_eventHandler->StopListen(this, &TriggerObject::OnTriggerHit);
	delete m_collider;
}

