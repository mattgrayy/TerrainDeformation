#pragma once

#include "TriggerObject.h"
#include "Collision.h"

class Trap : public TriggerObject
{
public:
	Trap(GameData* _GD, ID3D11Device* _D, string _fileName, Vector2 _pos);
	virtual ~Trap() = default;

	virtual void OnTriggerHit(const TriggerEvent& evnt) override;
};