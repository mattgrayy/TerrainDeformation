#pragma once
#include "StaticObject.h"
#include "ColliderBox.h"
#include "Collision.h"

class TriggerObject : public StaticObject
{
public:
	TriggerObject(GameData* _GD, ID3D11Device* _D, string _fileName, Vector2 _pos);
	virtual ~TriggerObject();

	virtual void OnTriggerHit(const TriggerEvent& evnt) = 0;

private:
	ColliderBox* m_collider;

};

