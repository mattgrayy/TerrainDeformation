#pragma once
#include "Behaviour.h"

class BehaviourBlocker :
	public Behaviour
{
public:
	BehaviourBlocker(GameData* _GD);
	virtual ~BehaviourBlocker();

	virtual void Init(Lemming* lemming);

	virtual void Tick(Lemming* lemming);

private:

	bool falling = true;
};

