#include "ImageGO2D.h"
#include "WICTextureLoader.h"
#include "DrawData2D.h"
#include "GameData.h"
#include "helper.h"

ImageGO2D::ImageGO2D(GameData* _GD, string _fileName, ID3D11Device* _D)
	: GameObject2D(_GD), m_pTextureRV(nullptr), imageEffect(SpriteEffects_None)
{
	string fullfilename =
#if DEBUG
		"../Debug/"
#else
		"../Release/"
#endif
		+ _fileName + ".png";
	HRESULT hr = CreateWICTextureFromFile(_D, Helper::charToWChar(fullfilename.c_str()), nullptr, &m_pTextureRV);

	//this nasty thing is required to find out the size of this image!
	ID3D11Resource *pResource;
	D3D11_TEXTURE2D_DESC Desc;
	m_pTextureRV->GetResource(&pResource);
	((ID3D11Texture2D *)pResource)->GetDesc(&Desc);

	m_size.x = Desc.Width;
	m_size.y = Desc.Height;

	m_origin = 0.5f * m_size; //around which rotation and scaing is done
}

ImageGO2D::~ImageGO2D()
{
	if (m_pTextureRV)
	{
		m_pTextureRV->Release();
		m_pTextureRV = nullptr;
	}
}

void ImageGO2D::Tick()
{
	GameObject2D::Tick();
}

void ImageGO2D::Draw(DrawData2D* _DD)
{
	//nullptr can be changed to a RECT* to define what area of this image to grab
	//you can also add an extra value at the end to define layer depth
	_DD->m_Sprites->Draw(m_pTextureRV, m_pos, nullptr, m_colour, m_rotation, m_origin, m_scale,imageEffect);
}

void ImageGO2D::FlipImageHoriz()
{
	switch (imageEffect)
	{
	case SpriteEffects_None:
		imageEffect = SpriteEffects_FlipHorizontally;
		break;
	case SpriteEffects_FlipHorizontally:
		imageEffect = SpriteEffects_None;
		break;
	case SpriteEffects_FlipVertically:
		imageEffect = SpriteEffects_FlipBoth;
		break;
	case SpriteEffects_FlipBoth:
		imageEffect = SpriteEffects_FlipVertically;
		break;
	}
}