

#include "EventHandler.h"


void EventHandler::ProcessEvents()
{
	for(auto& func : processEventsFuncs)
	{
		func(this);
	}
}
