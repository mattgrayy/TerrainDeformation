#include "BehaviourMiner.h"
#include "GameData.h"
#include "BehaviourManager.h"
#include "Level.h"

BehaviourMiner::BehaviourMiner(GameData* _GD)
	: Behaviour(_GD)
{
}


BehaviourMiner::~BehaviourMiner()
{
}

void BehaviourMiner::OnHitFloor(Lemming* lemming)
{
	if (digging && m_fallTimer >= 0.5f)
	{
		lemming->resetBehaviour();
		return;
	}
	if (!digging)
	{
		digging = true;
	}
	if (lemming->GetVelocity().x > 0)
	{
		m_GD->m_behaviorManager->_level->MakeHole(Vector2(lemming->GetPos().x + (lemming->GetColBox()->GetSize().x / 1.5f), lemming->GetPos().y + (lemming->GetColBox()->GetSize().y / 4)), lemming->GetColBox()->GetSize().y);

	}
	else
	{
		m_GD->m_behaviorManager->_level->MakeHole(Vector2(lemming->GetPos().x - (lemming->GetColBox()->GetSize().x / 1.5f), lemming->GetPos().y + (lemming->GetColBox()->GetSize().y / 4)), lemming->GetColBox()->GetSize().y);
	}
	lemming->GetPos().x += m_GD->m_dt * lemming->GetVelocity().x * 4;

	if (m_fallTimer > 3.0f)
	{
		lemming->kill();
	}
	m_fallTimer = 0.0f;
}