#pragma once
#include "ImageGO2D.h"
#include "ColliderPoint.h"
#include "ColliderBox.h"
#include "Collision.h"
#include <vector>

class Behaviour;

//Create Args: GameData* _GD, string _fileName, ID3D11Device* _D
// m_tag = "Lemming"
//The base Lemming class for all lemmings.
class Lemming : public ImageGO2D
{
public:
	Lemming(GameData* _GD, string _fileName, ID3D11Device* _D);
	~Lemming();

	virtual void Tick();
	void OnCollision(const CollisionEvent& evnt);

	void changeBehaviour();
	void resetBehaviour();

	// getters
	ColliderBox* GetColBox() { return m_colBox; }
	Vector2& GetVelocity() { return m_velocity; }

	Vector2& GetPos() { return m_pos; }

	bool GetGrounded() { return m_grounded;  }

	void kill();

	// setters
	void SetVelocity(const Vector2& vel) { m_velocity = vel; }
	void SetGrounded(bool grounded) { m_grounded = grounded; }

private:

	bool m_resetBehaviour = false;

	Vector2 m_velocity;
	bool m_grounded; // needs to be fully implemented

	Behaviour* m_behaviour;

	ColliderBox* m_colBox;

	ColliderPoint* m_feetPos;
	ColliderPoint* m_leftPos;
	ColliderPoint* m_rightPos;
};