#include "Lemming.h"
#include "GameData.h"
#include "AllBehaviours.h"
#include "BehaviourManager.h"
#include "ButtonBehaviour.h"
#include "Input.h"

Lemming::Lemming(GameData* _GD, string _fileName, ID3D11Device* _D)
	: ImageGO2D(_GD, _fileName, _D), m_velocity(50,50),m_grounded(false)
{
	m_tag = "Lemming";

	m_behaviour = _GD->m_behaviorManager->requestBehaviour(BehaviourType::BehaviourBaseT, _GD);

	m_feetPos = new ColliderPoint(&m_pos, this, _GD->m_collisionGroup, Vector2(0.0f, m_size.y/2 -1));
	m_leftPos = new ColliderPoint(&m_pos, this, _GD->m_collisionGroup, Vector2(-m_size.x / 2, 0.0f));
	m_rightPos = new ColliderPoint(&m_pos, this, _GD->m_collisionGroup, Vector2(m_size.x / 2 -1, 0.0f));
	m_colBox = new ColliderBox(&m_pos, this, _GD->m_collisionGroup, m_size, true, true);
	
	m_feetPos->AddCollideTag("Level", "Exit", "Trap", "LemmingBlocker");
	m_leftPos->AddCollideTag("Level", "Exit", "Trap", "LemmingBlocker");
	m_rightPos->AddCollideTag("Level", "Exit", "Trap", "LemmingBlocker");
	m_colBox->AddCollideTag("Lemming");

	_GD->m_eventHandler->StartListen(this, &Lemming::OnCollision);
}

Lemming::~Lemming()
{
	m_GD->m_eventHandler->StopListen(this, &Lemming::OnCollision);
	delete m_feetPos;
	delete m_leftPos;
	delete m_rightPos; 
	delete m_colBox;
	delete m_behaviour;
}

void Lemming::OnCollision(const CollisionEvent& evnt)
{
	if (evnt.obj1 != this)
	{
		return;
	}

	Vector2 moved = evnt.movement;
	
	if (evnt.col1 == m_feetPos)
	{
		m_pos.x -= evnt.movement.x;
		moved.x = 0.0f;
	}
	else
	{
		m_pos.y -= evnt.movement.y;
		moved.y = 0.0f;
	}

	if (evnt.obj1 == evnt.obj2)
	{
		return;
	}

	if (moved.y < 0)
	{
		//hit ground
		m_behaviour->OnHitFloor(this);
	}

	if (moved.x < 0)
	{
		// hit wall
		m_behaviour->OnHitWall(this);
	}
	if (moved.x > 0)
	{
		// hit wall
		m_behaviour->OnHitWall(this);
	}
}

void Lemming::Tick()
{
	if (m_resetBehaviour)
	{
		float b_fallTimer = m_behaviour->getFallTimer();

		delete m_behaviour;
		m_behaviour = m_GD->m_behaviorManager->requestBehaviour(BehaviourType::BehaviourBaseT, m_GD);
		m_behaviour->setFallTimer(b_fallTimer);
		m_behaviour->Init(this);
		m_resetBehaviour = false;
	}

	m_behaviour->Tick(this);

	if (Input::GetMouseButtonDown(0))
	{
		Vector2 mousePos = Vector2(Input::GetMouseX(), Input::GetMouseY());

			if (m_GD->m_collisionGroup->PointCast(mousePos) == this)
			{
				if (m_GD->m_selectedButton != nullptr){
					if (m_GD->m_selectedButton->getUses() > 0)
					{
						changeBehaviour();
					}
					else
					{
						m_GD->m_selectedButton = nullptr;
					}
				}
			}
	}
}

void Lemming::resetBehaviour()
{
	m_resetBehaviour = true;
}

void Lemming::changeBehaviour()
{
	float b_fallTimer = m_behaviour->getFallTimer();

	delete m_behaviour;
	m_behaviour = m_GD->m_behaviorManager->requestBehaviour(m_GD->m_selectedBehType, m_GD);

	m_behaviour->setFallTimer(b_fallTimer);
	m_behaviour->Init(this);
	m_GD->m_selectedButton->use();
}

void Lemming::kill()
{
	m_GD->m_factory->Delete(this);
}