#include "BehaviourBomber.h"
#include "GameData.h"
#include "BehaviourManager.h"
#include "Level.h"

BehaviourBomber::BehaviourBomber(GameData* _GD)
	: m_bombTimer(0.0f), Behaviour(_GD)
{
}


BehaviourBomber::~BehaviourBomber()
{
}

void BehaviourBomber::Tick(Lemming* lemming)
{
	if (m_bombTimer < 5.01f){
		lemming->GetPos().y += m_GD->m_dt * lemming->GetVelocity().y;
		m_bombTimer += m_GD->m_dt;
		if (m_bombTimer > 5.0f)
		{
			m_GD->m_behaviorManager->_level->MakeHole(lemming->GetPos(), 80.0f);
			lemming->kill();
		}
	}
}