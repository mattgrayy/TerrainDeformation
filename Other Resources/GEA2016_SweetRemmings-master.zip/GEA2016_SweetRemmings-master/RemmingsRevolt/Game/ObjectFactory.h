#pragma once
#include <list>
#include <string>
#include <map>
#include "GameObject2D.h"

#include "EventHandler.h"


class Level;


struct BehaviourCount {
	BehaviourCount(int _basher, int _blocker, int _bomber, int _builder, int _climber, int _digger, int _floater, int _miner)
		: m_basher(_basher), m_blocker(_blocker), m_bomber(_bomber), m_builder(_builder), m_climber(_climber), m_digger(_digger), m_floater(_floater), m_miner(_miner) {
	}

	int m_basher = 0,
		m_blocker = 0,
		m_bomber = 0,
		m_builder = 0,
		m_climber = 0,
		m_digger = 0,
		m_floater = 0,
		m_miner = 0;
};

class DeleteEvent
{
public:
	DeleteEvent(GameObject2D* _obj)
		: m_obj(_obj)
	{}

	GameObject2D* m_obj;
};

/*
  @author Sam Richards
  The object factory to create all game objects.
*/
class ObjectFactory
{
public:
	ObjectFactory(EventHandler* _eventHandler)
		: m_eventHandler(_eventHandler)
	{}
	~ObjectFactory();

	//Creates a new object of a given type, feeds through parameters and returns a pointer to the object in a vector.
	template<typename T, typename... Args>
	T* CreateGameObject(const Args& ... _args)
	{
		T* newObj = new T(_args...);
		m_gameObjects.push_back(newObj);
		return newObj;
	}

	void Delete(GameObject2D* obj);
	void DoDeletion();

	Level* LoadLevelFromFile(GameData* _GD, ID3D11Device* _D, string fileName);

	//Returns all game objects created by this factory.
	const std::list<GameObject2D*>& GetGameObject2Ds() const;

private:
	//The main list of game objects, used to staticly refer to all active objects of the game when drawing and updating.
	std::list<GameObject2D*> m_gameObjects;

	std::list<GameObject2D*> m_objsToDelete;

	EventHandler* m_eventHandler;
};

