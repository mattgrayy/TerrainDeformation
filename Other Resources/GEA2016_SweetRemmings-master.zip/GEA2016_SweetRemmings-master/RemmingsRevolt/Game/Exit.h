#pragma once
#include "TriggerObject.h"

class Level;
class Lemming;

class ExitEvent
{
public:
	ExitEvent(Lemming* _lemming)
		: m_lemming(_lemming)
	{}

	Lemming* m_lemming;
};

class Exit :
	public TriggerObject
{
public:
	Exit(GameData* _GD, ID3D11Device* _D, Level* _level, string _fileName, Vector2 _pos);
	virtual ~Exit();

	virtual void OnTriggerHit(const TriggerEvent& evnt) override;

private:
	Level* m_level;
};

