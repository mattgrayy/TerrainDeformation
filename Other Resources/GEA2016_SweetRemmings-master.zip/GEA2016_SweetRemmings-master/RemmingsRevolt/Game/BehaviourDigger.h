#pragma once
#include "Behaviour.h"
class BehaviourDigger :
	public Behaviour
{
public:
	BehaviourDigger(GameData* _GD);
	virtual ~BehaviourDigger();

	virtual void OnHitFloor(Lemming* lemming);
private:
	bool digging = false;
};

