#pragma once
#include "Button.h"
#include "TextGO2D.h"
#include "ColliderBox.h"
#include "Behaviour.h"
#include "GameData.h"
class ButtonBehaviour : public Button
{
public:
	ButtonBehaviour(GameData* _GD, string _filename, ID3D11Device* _D, BehaviourType butHaviour, int butUses, int posIndex);
	virtual ~ButtonBehaviour();

	virtual void Tick() override;

	void use(){ m_uses--; }
	int getUses() { return m_uses; }

	virtual void OnClicked() override;

private:
	BehaviourType m_behaviour;

	int m_uses = 0;
};

