#pragma once
#include "Behaviour.h"
class BehaviourBuilder :
	public Behaviour
{
public:
	BehaviourBuilder(GameData* _GD);
	virtual ~BehaviourBuilder();


	virtual void OnHitFloor(Lemming* lemming);
	virtual void Tick(Lemming* lemming);

private:
	float m_placeTimer;
};