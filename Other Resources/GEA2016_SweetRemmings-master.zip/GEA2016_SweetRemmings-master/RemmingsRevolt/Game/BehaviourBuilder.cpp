#include "BehaviourBuilder.h"
#include "GameData.h"
#include "BehaviourManager.h"
#include "Level.h"

BehaviourBuilder::BehaviourBuilder(GameData* _GD)
	: Behaviour(_GD), m_placeTimer(0.0f)
{
}


BehaviourBuilder::~BehaviourBuilder()
{
}

void BehaviourBuilder::OnHitFloor(Lemming* lemming)
{
	if (m_fallTimer > 3.0f)
	{
		lemming->kill();
	}
	m_fallTimer = 0.0f;

	m_placeTimer += m_GD->m_dt;
	// we need to move forward
	if (m_placeTimer < 0.35f && m_placeTimer > 0.2f)
	{
		lemming->SetGrounded(true);
	}
	else if (m_placeTimer > 0.35f)
	{
		m_placeTimer = 0.0f;
		// drop a slab
		if (lemming->GetVelocity().x > 0)
		{
			m_GD->m_behaviorManager->_level->MakeBrick(Vector2(lemming->GetPos().x + (lemming->GetColBox()->GetSize().x / 2), lemming->GetPos().y + (lemming->GetColBox()->GetSize().y / 2)));
			lemming->GetPos().y += m_GD->m_dt * lemming->GetVelocity().y;

		}
		else
		{
			m_GD->m_behaviorManager->_level->MakeBrick(Vector2(lemming->GetPos().x - (lemming->GetColBox()->GetSize().x / 2), lemming->GetPos().y + (lemming->GetColBox()->GetSize().y / 2)));
			lemming->GetPos().y += m_GD->m_dt * lemming->GetVelocity().y;
		}
	}
	else
	{
		lemming->SetGrounded(false);
	}
}

void BehaviourBuilder::Tick(Lemming* lemming)
{
	OnFalling(lemming);
	lemming->GetPos().y += m_GD->m_dt * lemming->GetVelocity().y;

	if (lemming->GetGrounded())
	{
		lemming->GetPos().x += m_GD->m_dt * lemming->GetVelocity().x;
	}
	lemming->SetGrounded(false);
}