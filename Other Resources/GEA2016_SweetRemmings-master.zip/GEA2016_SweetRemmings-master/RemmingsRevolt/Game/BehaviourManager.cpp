#include "BehaviourManager.h"


BehaviourManager::BehaviourManager(GameData* _GD)
{
	_behDefault = new Behaviour(_GD);
	_behBasher = new BehaviourBasher(_GD);
	_behBlocker = new BehaviourBlocker(_GD);
	_behBomber = new BehaviourBomber(_GD);
	_behBuilder = new BehaviourBuilder(_GD);
	_behClimber = new BehaviourClimber(_GD);
	_behDigger = new BehaviourDigger(_GD);
	_behFloater = new BehaviourFloater(_GD);
	_behMiner = new BehaviourMiner(_GD);
}


BehaviourManager::~BehaviourManager()
{
	//delete m_behaviors[0];
	//delete m_behaviors[1];
	//delete m_behaviors[2];
	//delete m_behaviors[3];
	//delete m_behaviors[4];
	//delete m_behaviors[5];
	//delete m_behaviors[6];
	//delete m_behaviors[7];
	//delete m_behaviors[8];
}

Behaviour* BehaviourManager::requestBehaviour(BehaviourType _type, GameData* _GD)
{
	switch (_type)
	{
	case BehaviourType::BehaviourBaseT:
		return new Behaviour(_GD);
		break;
	case BehaviourType::BehaviourBasherT:
		return new BehaviourBasher(_GD);
		break;
	case BehaviourType::BehaviourBlockerT:
		return new BehaviourBlocker(_GD);
		break;
	case BehaviourType::BehaviourBomberT:
		return new BehaviourBomber(_GD);
		break;
	case BehaviourType::BehaviourBuilderT:
		return new BehaviourBuilder(_GD);
		break;
	case BehaviourType::BehaviourClimberT:
		return new BehaviourClimber(_GD);
		break;
	case BehaviourType::BehaviourDiggerT:
		return new BehaviourDigger(_GD);
		break;
	case BehaviourType::BehaviourFloaterT:
		return new BehaviourFloater(_GD);
		break;
	case BehaviourType::BehaviourMinerT:
		return new BehaviourMiner(_GD);
		break;
	default:
		break;
	}
}